Sounds:
sounds = default.node_sound_sand_defaults(),
sounds = default.node_sound_stone_defaults(),
sounds = default.node_sound_wood_defaults(),
sounds = default.node_sound_glass_defaults(),

Copyright (C) 2010-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/


.png's:
default_sand.png
VanessaE (WTFPL)

default_dirt.png
default_tree.png
default_chest_front.png
default_chest_side.png
default_chest_top.png
Cisoun's WTFPL texture pack

default_wood.png
Originating from G4JC's Almost MC Texture Pack

default_steel_block.png
default_copper_block.png
default_bronze_block.png
Zeg9 (CC BY-SA 3.0)

default_obsidian_glass.png
PilzAdam (WTFPL)


Code:
minetest/games/minetest_game/mods/default/mapgen.lua --> ore generation

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>
GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.