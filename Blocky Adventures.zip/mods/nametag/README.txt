Mod "Nametag" [nametag]
=======================
Copyright (c) 2015 BlockMen <blockmen2015@gmail.com>

Version: 1.0 alpha


A simple mod that allows to give nearly every object a name, only Players can't be renamed.

You can craft a nametag with paper and coal. To rename an object rightlick it with the nametag,
then you can type the wanted name.

NOTE: This mod requires a current development build of Minetest from 16th December 2015 or newer. Also useable with blockplanet.


License: 
~~~~~~~~
Code:
(c) Copyright 2015 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Media(if not stated differently):
(c) Copyright (2015) BlockMen; CC-BY-SA 3.0


Github:
~~~~~~~
https://github.com/BlockMen/nametag


Forum:
~~~~~~
-


Changelog:
~~~~~~~~~~
-
