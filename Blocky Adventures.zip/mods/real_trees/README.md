<strong>Real Trees</strong>

This mod aims to make the growth of minetest trees a litte more harder and realistic by adding them stages of growing.
  
   - there are 3 stages between the sapling and the full tree
   - the growing time differs on each tree
   - small trees can be harvested but gives less wood than a full tree
   - the growth can start only with sunlight
 
