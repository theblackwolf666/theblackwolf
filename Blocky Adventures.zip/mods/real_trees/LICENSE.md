This software is licensed uder the following licences:

  Textures:[CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/legalcode)
    
  changes were made on all default tree textures, to fit better with small trees.
    
  Code:[WTFPL](http://www.wtfpl.net/txt/copying/)
