-- Defines the base time of growth in seconds

growth_time =	{
				["apple"]  = 450,
				["pine"]   = 330,
				["aspen"]  = 330,
				["acacia"] = 510,
				["jungle"] = 570
				}



