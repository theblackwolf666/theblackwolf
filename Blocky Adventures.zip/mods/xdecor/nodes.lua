function xdecor.register_storage(name, desc, def)
	xdecor.register(name, {
		description = desc,
		inventory = {size=def.inv_size or 24},
		infotext = desc,
		tiles = def.tiles,
		node_box = def.node_box,
		on_rotate = def.on_rotate,
		on_place = def.on_place,
		groups = def.groups or {choppy=2, oddly_breakable_by_hand=1, flammable=2},
		sounds = default.node_sound_wood_defaults()
	})
end

xdecor.register_storage("cabinet", "Wooden Cabinet", {
	tiles = {"xdecor_cabinet_sides.png", "xdecor_cabinet_sides.png",
		 "xdecor_cabinet_sides.png", "xdecor_cabinet_sides.png",
		 "xdecor_cabinet_sides.png", "xdecor_cabinet_front.png"}
})

xdecor.register_storage("cabinet_half", "Half Wooden Cabinet", {
	inv_size = 8,
	node_box = xdecor.nodebox.slab_y(0.5, 0.5),
	tiles = {"xdecor_cabinet_sides.png", "xdecor_cabinet_sides.png",
		 "xdecor_half_cabinet_sides.png", "xdecor_half_cabinet_sides.png",
		 "xdecor_half_cabinet_sides.png", "xdecor_half_cabinet_front.png"}
})

xdecor.register("chair", {
	description = "Chair",
	tiles = {"default_pine_tree.png"},
	sounds = default.node_sound_wood_defaults(),
	groups = {choppy=3, oddly_breakable_by_hand=2, flammable=2},
	node_box = xdecor.pixelbox(16, {
		{3,  0, 11,   2, 16, 2}, {11, 0, 11,  2, 16, 2},
		{5,  9, 11.5, 6,  6, 1}, {3,  0,  3,  2,  6, 2},
		{11, 0,  3,   2,  6, 2}, {3,  6,  3, 10, 2, 8}
	}),
	can_dig = xdecor.sit_dig,
	on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
		pos.y = pos.y + 0  -- Sitting position.
		xdecor.sit(pos, node, clicker, pointed_thing)
		return itemstack
	end
})

xdecor.register("cobweb", {
	description = "Cobweb",
	drawtype = "plantlike",
	tiles = {"xdecor_cobweb.png"},
	inventory_image = "xdecor_cobweb.png",
	liquid_viscosity = 8,
	liquidtype = "source",
	liquid_alternative_flowing = "xdecor:cobweb",
	liquid_alternative_source = "xdecor:cobweb",
	liquid_renewable = false,
	liquid_range = 0,
	walkable = false,
	selection_box = {type = "regular"},
	groups = {snappy=3, liquid=3, flammable=3},
	sounds = default.node_sound_leaves_defaults()
})

xdecor.register("enderchest", {
	description = "Enchanted Chest",
	tiles = {"xdecor_enderchest_top.png", "xdecor_enderchest_top.png",
		 "xdecor_enderchest_side.png", "xdecor_enderchest_side.png",
		 "xdecor_enderchest_side.png", "xdecor_enderchest_front.png"},
	groups = {cracky=1, choppy=1},
	sounds = default.node_sound_stone_defaults(),
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", [[ size[8,9]
				list[current_player;enderchest;0,0;8,4;]
				list[current_player;main;0,5;8,4;]
				listring[current_player;enderchest]
				listring[current_player;main] ]]
				..xbg..default.get_hotbar_bg(0,5))
		meta:set_string("infotext", "Enchanted Chest")
	end
})

minetest.register_on_joinplayer(function(player)
	local inv = player:get_inventory()
	inv:set_size("enderchest", 8*4)
end)

xdecor.register("lantern", {
	description = "Lantern",
	light_source = 13,
	drawtype = "plantlike",
	inventory_image = "xdecor_lantern_inv.png",
	wield_image = "xdecor_lantern_inv.png",
	paramtype2 = "wallmounted",
	walkable = false,
	groups = {snappy=3, attached_node=1},
	tiles = {{name = "xdecor_lantern.png", animation = {type="vertical_frames", length=1.5}}},
	selection_box = xdecor.pixelbox(16, {{4, 0, 4, 8, 16, 8}})
})

xdecor.register("stonepath", {
	description = "Garden Stone Path",
	tiles = {"default_stone.png"},
	groups = {snappy=3},
	sounds = default.node_sound_stone_defaults(),
	sunlight_propagates = true,
	node_box = xdecor.pixelbox(16, {
		{8, 0,  8, 6, .5, 6}, {1,  0, 1, 6, .5, 6},
		{1, 0, 10, 5, .5, 5}, {10, 0, 2, 4, .5, 4}
	}),
	selection_box = xdecor.nodebox.slab_y(0.05)
})

xdecor.register("table", {
	description = "Table",
	tiles = {"default_wood.png"},
	groups = {choppy=2, oddly_breakable_by_hand=1, flammable=2},
	sounds = default.node_sound_wood_defaults(),
	node_box = xdecor.pixelbox(16, {
		{0, 14, 0, 16, 2, 16}, {5.5, 0, 5.5, 5, 14, 6}
	})
})

xdecor.register("trampoline", {
	description = "Trampoline",
	tiles = {"xdecor_trampoline.png", "mailbox_blank16.png", "xdecor_trampoline_sides.png"},
	groups = {cracky=3, oddly_breakable_by_hand=1, fall_damage_add_percent=-80, bouncy=90},
	node_box = xdecor.nodebox.slab_y(0.5),
	sounds = {footstep = {name="xdecor_bouncy", gain=0.8}}
})