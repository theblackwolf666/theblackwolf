-- Code by Mossmanikin
-----------------------------------------------------------------------------------------------
-- TWiGS
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- *leaves --> twigs
	output = "default:stick 2",
	recipe = {{"group:leafdecay"}}
})
if minetest.get_modpath("moretrees") ~= nil then
minetest.register_craft({ -- moretrees_leaves --> twigs
	output = "default:stick 2",
	recipe = {{"group:moretrees_leaves"}}
})
minetest.register_craft({ -- except moretrees:palm_leaves
	output = "default:stick",
	recipe = {{"moretrees:palm_leaves"}}
})
end
if minetest.get_modpath("bushes") ~= nil then
minetest.register_craft({ -- BushLeaves --> twigs
	output = "default:stick 2",
	recipe = {{"bushes:BushLeaves1"}}
})
minetest.register_craft({
	output = "default:stick 2",
	recipe = {{"bushes:BushLeaves2"}}
})
minetest.register_craft({ -- bushbranches --> twigs
	output = "default:stick 4",
	recipe = {{"bushes:bushbranches1"}}
})
minetest.register_craft({
	output = "default:stick 4",
	recipe = {{"bushes:bushbranches2"}}
})
minetest.register_craft({
	output = "default:stick 4",
	recipe = {{"bushes:bushbranches2a"}}
})
minetest.register_craft({
	output = "default:stick 4",
	recipe = {{"bushes:bushbranches3"}}
})
end

minetest.register_craft({ -- twigs block --> twigs
	output = "default:stick 8",
	recipe = {{"trunks:twigs"}}
})

-----------------------------------------------------------------------------------------------
-- STiCK
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- twig --> stick
	output = "default:stick",
	recipe = {{"trunks:twig_1"}}
})

-----------------------------------------------------------------------------------------------
-- TWiGS BLoCK
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- twigs --> twigs block
	output = "trunks:twigs",
	recipe = {
		{"default:stick","default:stick","default:stick"},
		{"default:stick",      ""       ,"default:stick"},
		{"default:stick","default:stick","default:stick"},
	}
})

-----------------------------------------------------------------------------------------------
-- TWiGS SLaBS
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- twigs blocks --> twigs_slabs
	output = "trunks:twigs_slab 3",
	recipe = {
		{"default:stick","default:stick","default:stick"},
	}
})

-----------------------------------------------------------------------------------------------
-- TWiGS RooFS
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- twigs blocks --> twigs_roofs
	output = "trunks:twigs_roof 2",
	recipe = {
		{"default:stick",""},
		{"","default:stick"},
	}
})
minetest.register_craft({
	output = "trunks:twigs_roof 2",
	recipe = {
		{"","default:stick"},
		{"default:stick",""},
	}
})

-----------------------------------------------------------------------------------------------
-- TWiGS RooF CoRNeRS
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- twigs blocks --> twigs_roof_corners
	output = "trunks:twigs_roof_corner 3",
	recipe = {
		{      ""      ,"default:stick",      ""      },
		{"default:stick",      ""      ,"default:stick"},
	}
})

-----------------------------------------------------------------------------------------------
-- TWiGS RooF CoRNeRS 2
-----------------------------------------------------------------------------------------------
minetest.register_craft({ -- twigs blocks --> twigs_roof_corner_2's
	output = "trunks:twigs_roof_corner_2 3",
	recipe = {
		{"default:stick",      ""      ,"default:stick"},
		{      ""      ,"default:stick",      ""      },
	}
})