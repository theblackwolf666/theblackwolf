treasurer.register_treasure("bucket:bucket_empty",0.01,3.5,{1,3},nil,"tool")
