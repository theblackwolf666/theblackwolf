treasurer.register_treasure("xpanes:bar",0.05,4,{1,8},nil,"building_block")
treasurer.register_treasure("xpanes:pane",0.08,4,{1,16},nil,"building_block")
