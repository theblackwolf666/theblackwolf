-- registers TNT and gunpowder

treasurer.register_treasure("tnt:tnt",0.05,5,nil,nil,"minetool")
treasurer.register_treasure("tnt:gunpowder",0.123,3,{1,10},nil,"crafting_component")
