treasurer.register_treasure("boats:boat",0.001,4,nil,nil,"transport_vehicle")
