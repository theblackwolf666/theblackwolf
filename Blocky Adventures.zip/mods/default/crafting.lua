-- mods/default/crafting.lua

minetest.register_craft({
	output = 'default:wood 4',
	recipe = {
		{'default:tree'},
	}
})

minetest.register_craft({
	output = 'default:junglewood 4',
	recipe = {
		{'default:jungletree'},
	}
})

minetest.register_craft({
	output = 'default:log_wood 4',
	recipe = {
		{'default:log'},
	}
})

minetest.register_craft({
	output = 'default:pine_wood 4',
	recipe = {
		{'default:pine_tree'},
	}
})

minetest.register_craft({
	output = 'default:acacia_wood 4',
	recipe = {
		{'default:acacia_tree'},
	}
})

minetest.register_craft({
	output = 'default:aspen_wood 4',
	recipe = {
		{'default:aspen_tree'},
	}
})

minetest.register_craft({
	output = 'default:stick 4',
	recipe = {
		{''},
		{'group:wood'},
		{'group:wood'},
	}
})

minetest.register_craft({
	output = 'default:sign_wall_steel 3',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:sign_wall_wood 3',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_wood',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_stone',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_steel',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_bronze',
	recipe = {
		{'default:bronze_ingot', 'default:bronze_ingot', 'default:bronze_ingot'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_mese',
	recipe = {
		{'default:mese_crystal', 'default:mese_crystal', 'default:mese_crystal'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_diamond',
	recipe = {
		{'default:diamond', 'default:diamond', 'default:diamond'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_wood',
	recipe = {
		{'group:wood'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_stone',
	recipe = {
		{'group:stone'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_steel',
	recipe = {
		{'default:steel_ingot'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_bronze',
	recipe = {
		{'default:bronze_ingot'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_mese',
	recipe = {
		{'default:mese_crystal'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_diamond',
	recipe = {
		{'default:diamond'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_wood',
	recipe = {
		{'group:wood', 'group:wood'},
		{'group:wood', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_stone',
	recipe = {
		{'group:stone', 'group:stone'},
		{'group:stone', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_steel',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_bronze',
	recipe = {
		{'default:bronze_ingot', 'default:bronze_ingot'},
		{'default:bronze_ingot', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_mese',
	recipe = {
		{'default:mese_crystal', 'default:mese_crystal'},
		{'default:mese_crystal', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_diamond',
	recipe = {
		{'default:diamond', 'default:diamond'},
		{'default:diamond', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_wood',
	recipe = {
		{'group:wood', 'group:wood'},
		{'group:stick', 'group:wood'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:axe_stone',
	recipe = {
		{'group:stone', 'group:stone'},
		{'group:stick', 'group:stone'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:axe_steel',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot'},
		{'group:stick', 'default:steel_ingot'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:axe_bronze',
	recipe = {
		{'default:bronze_ingot', 'default:bronze_ingot'},
		{'group:stick', 'default:bronze_ingot'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:axe_mese',
	recipe = {
		{'default:mese_crystal', 'default:mese_crystal'},
		{'group:stick', 'default:mese_crystal'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:axe_diamond',
	recipe = {
		{'default:diamond', 'default:diamond'},
		{'group:stick', 'default:diamond'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:sword_wood',
	recipe = {
		{'group:wood'},
		{'group:wood'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_stone',
	recipe = {
		{'group:stone'},
		{'group:stone'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_steel',
	recipe = {
		{'default:steel_ingot'},
		{'default:steel_ingot'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_bronze',
	recipe = {
		{'default:bronze_ingot'},
		{'default:bronze_ingot'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_mese',
	recipe = {
		{'default:mese_crystal'},
		{'default:mese_crystal'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_diamond',
	recipe = {
		{'default:diamond'},
		{'default:diamond'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:rail 24',
	recipe = {
		{'default:steel_ingot', '', 'default:steel_ingot'},
		{'default:steel_ingot', 'group:stick', 'default:steel_ingot'},
		{'default:steel_ingot', '', 'default:steel_ingot'},
	}
})

minetest.register_craft({
	output = 'default:chest',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:wood', '', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	output = 'default:furnace',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'group:stone', '', 'group:stone'},
		{'group:stone', 'group:stone', 'group:stone'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bronze_ingot",
	recipe = {"default:steel_ingot", "default:copper_ingot"},
})

minetest.register_craft({
	output = 'default:coalblock',
	recipe = {
		{'default:coal_lump', 'default:coal_lump', 'default:coal_lump'},
		{'default:coal_lump', 'default:coal_lump', 'default:coal_lump'},
		{'default:coal_lump', 'default:coal_lump', 'default:coal_lump'},
	}
})

minetest.register_craft({
	output = 'default:coal_lump 9',
	recipe = {
		{'default:coalblock'},
	}
})

minetest.register_craft({
	output = 'default:steelblock',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
	}
})

minetest.register_craft({
	output = 'default:steel_ingot 9',
	recipe = {
		{'default:steelblock'},
	}
})

minetest.register_craft({
	output = 'default:copperblock',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
	}
})

minetest.register_craft({
	output = 'default:copper_ingot 9',
	recipe = {
		{'default:copperblock'},
	}
})

minetest.register_craft({
	output = 'default:bronzeblock',
	recipe = {
		{'default:bronze_ingot', 'default:bronze_ingot', 'default:bronze_ingot'},
		{'default:bronze_ingot', 'default:bronze_ingot', 'default:bronze_ingot'},
		{'default:bronze_ingot', 'default:bronze_ingot', 'default:bronze_ingot'},
	}
})

minetest.register_craft({
	output = 'default:bronze_ingot 9',
	recipe = {
		{'default:bronzeblock'},
	}
})

minetest.register_craft({
	output = 'default:goldblock',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
	}
})

minetest.register_craft({
	output = 'default:gold_ingot 9',
	recipe = {
		{'default:goldblock'},
	}
})

minetest.register_craft({
	output = 'default:diamondblock',
	recipe = {
		{'default:diamond', 'default:diamond', 'default:diamond'},
		{'default:diamond', 'default:diamond', 'default:diamond'},
		{'default:diamond', 'default:diamond', 'default:diamond'},
	}
})

minetest.register_craft({
	output = 'default:diamond 9',
	recipe = {
		{'default:diamondblock'},
	}
})

minetest.register_craft({
	output = 'default:sandstone',
	recipe = {
		{'group:sand', 'group:sand'},
		{'group:sand', 'group:sand'},
	}
})

minetest.register_craft({
	output = 'default:sand 4',
	recipe = {
		{'default:sandstone'},
	}
})

minetest.register_craft({
	output = 'default:sandstonebrick 4',
	recipe = {
		{'default:sandstone', 'default:sandstone'},
		{'default:sandstone', 'default:sandstone'},
	}
})

minetest.register_craft({
	output = 'default:clay',
	recipe = {
		{'default:clay_lump', 'default:clay_lump'},
		{'default:clay_lump', 'default:clay_lump'},
	}
})

minetest.register_craft({
	output = 'default:clay_lump 4',
	recipe = {
		{'default:clay'},
	}
})

minetest.register_craft({
	output = 'default:brick',
	recipe = {
		{'default:clay_brick', 'default:clay_brick'},
		{'default:clay_brick', 'default:clay_brick'},
	}
})

minetest.register_craft({
	output = 'default:clay_brick 4',
	recipe = {
		{'default:brick'},
	}
})

minetest.register_craft({
	output = 'default:paper',
	recipe = {
		{'default:papyrus', 'default:papyrus', 'default:papyrus'},
	}
})

minetest.register_craft({
	output = 'default:book',
	recipe = {
		{'default:paper'},
		{'default:paper'},
		{'default:paper'},
	}
})

minetest.register_craft({
	output = 'default:bookshelf',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'default:book', 'default:book', 'default:book'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	output = 'default:ladder_wood 10',
	recipe = {
		{'group:stick', '', 'group:stick'},
		{'group:stick', 'group:stick', 'group:stick'},
		{'group:stick', '', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:ladder_steel 10',
	recipe = {
		{'default:steel_ingot', '', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', '', 'default:steel_ingot'},
	}
})

minetest.register_craft({
	output = 'default:mese',
	recipe = {
		{'default:mese_crystal', 'default:mese_crystal', 'default:mese_crystal'},
		{'default:mese_crystal', 'default:mese_crystal', 'default:mese_crystal'},
		{'default:mese_crystal', 'default:mese_crystal', 'default:mese_crystal'},
	}
})

minetest.register_craft({
	output = 'default:mese_crystal 9',
	recipe = {
		{'default:mese'},
	}
})

minetest.register_craft({
	output = 'default:mese_crystal_fragment 9',
	recipe = {
		{'default:mese_crystal'},
	}
})

minetest.register_craft({
	output = 'default:meselamp 1',
	recipe = {
		{'', 'default:mese_crystal',''},
		{'default:mese_crystal', 'default:glass', 'default:mese_crystal'},
	}
})

minetest.register_craft({
	output = 'default:obsidian_shard 9',
	recipe = {
		{'default:obsidian'}
	}
})

minetest.register_craft({
	output = 'default:obsidian',
	recipe = {
		{'default:obsidian_shard', 'default:obsidian_shard', 'default:obsidian_shard'},
		{'default:obsidian_shard', 'default:obsidian_shard', 'default:obsidian_shard'},
		{'default:obsidian_shard', 'default:obsidian_shard', 'default:obsidian_shard'},
	}
})

minetest.register_craft({
	output = 'default:obsidianbrick 4',
	recipe = {
		{'default:obsidian', 'default:obsidian'},
		{'default:obsidian', 'default:obsidian'}
	}
})

minetest.register_craft({
	output = 'default:stonebrick 4',
	recipe = {
		{'default:stone', 'default:stone'},
		{'default:stone', 'default:stone'},
	}
})

minetest.register_craft({
	output = 'default:desert_stonebrick 4',
	recipe = {
		{'default:desert_stone', 'default:desert_stone'},
		{'default:desert_stone', 'default:desert_stone'},
	}
})

minetest.register_craft({
	output = 'default:snowblock',
	recipe = {
		{'default:snow', 'default:snow', 'default:snow'},
		{'default:snow', 'default:snow', 'default:snow'},
		{'default:snow', 'default:snow', 'default:snow'},
	}
})

minetest.register_craft({
	output = 'default:snow 9',
	recipe = {
		{'default:snowblock'},
	}
})

--
-- Crafting (tool repair)
--
minetest.register_craft({
	type = "toolrepair",
	additional_wear = -0.02,
})

--
-- Cooking recipes
--

minetest.register_craft({
	type = "cooking",
	output = "default:glass",
	recipe = "group:sand",
})

minetest.register_craft({
	type = "cooking",
	output = "default:obsidian_glass",
	recipe = "default:obsidian_shard",
})

minetest.register_craft({
	type = "cooking",
	output = "default:stone",
	recipe = "default:cobble",
})

minetest.register_craft({
	type = "cooking",
	output = "default:stone",
	recipe = "default:mossycobble",
})

minetest.register_craft({
	type = "cooking",
	output = "default:desert_stone",
	recipe = "default:desert_cobble",
})

minetest.register_craft({
	type = "cooking",
	output = "default:steel_ingot",
	recipe = "default:iron_lump",
})

minetest.register_craft({
	type = "cooking",
	output = "default:copper_ingot",
	recipe = "default:copper_lump",
})

minetest.register_craft({
	type = "cooking",
	output = "default:gold_ingot",
	recipe = "default:gold_lump",
})

minetest.register_craft({
	type = "cooking",
	output = "default:clay_brick",
	recipe = "default:clay_lump",
})

--
-- Fuels
--

minetest.register_craft({
	type = "fuel",
	recipe = "group:tree",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:junglegrass",
	burntime = 2,
})

minetest.register_craft({
	type = "fuel",
	recipe = "group:leaves",
	burntime = 1,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:cactus",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:papyrus",
	burntime = 1,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:bookshelf",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:fence_wood",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:fence_acacia_wood",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:fence_junglewood",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:fence_pine_wood",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:fence_aspen_wood",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:ladder_wood",
	burntime = 5,
})

minetest.register_craft({
	type = "fuel",
	recipe = "group:wood",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:lava_source",
	burntime = 80,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:torch",
	burntime = 4,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:sign_wall_wood",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:chest",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:nyancat_rainbow",
	burntime = 9999999,
})

minetest.register_craft({
	type = "fuel",
	recipe = "group:sapling",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:apple",
	burntime = 3,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:coal_lump",
	burntime = 40,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:coalblock",
	burntime = 370,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:grass_1",
	burntime = 2,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:dry_grass_1",
	burntime = 2,
})

minetest.register_craft({
	output = 'default:pick_ob',
	recipe = {
		{'default:obsidian_shard', 'default:obsidian_shard', 'default:obsidian_shard'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_ob',
	recipe = {
		{'default:obsidian_shard'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_ob',
	recipe = {
		{'default:obsidian_shard', 'default:obsidian_shard'},
		{'default:obsidian_shard', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_ob',
	recipe = {
		{'default:obsidian_shard', 'default:obsidian_shard'},
		{'group:stick', 'default:obsidian_shard'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:sword_ob',
	recipe = {
		{'default:obsidian_shard'},
		{'default:obsidian_shard'},
		{'group:stick'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "default:steel_ingot",
	recipe = "default:boatmetal",
})

minetest.register_craft({
	type = "cooking",
	output = "default:steel_ingot",
	recipe = "default:boatplate",
})

minetest.register_craft({
	type = "cooking",
	output = "default:steel_ingot",
	recipe = "default:scrapiron",
})

minetest.register_craft({
	type = "cooking",
	output = "default:charcoal_lump",
	recipe = "group:tree",
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:charcoal_lump",
	burntime = 57,
})

minetest.register_craft({
	output = 'default:torch 4',
	recipe = {
		{'default:luna'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:pick_soul',
	recipe = {
		{'default:soul', 'default:soul', 'default:soul'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_soul',
	recipe = {
		{'default:soul'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_soul',
	recipe = {
		{'default:soul', 'default:soul'},
		{'default:soul', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_soul',
	recipe = {
		{'default:soul'},
		{'default:soul'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:rubyblock',
	recipe = {
		{'default:ruby', 'default:ruby', 'default:ruby'},
		{'default:ruby', 'default:ruby', 'default:ruby'},
		{'default:ruby', 'default:ruby', 'default:ruby'},
	}
})

minetest.register_craft({
	output = 'default:ruby 9',
	recipe = {
		{'default:rubyblock'},
	}
})

minetest.register_craft({
	output = 'default:lapisblock',
	recipe = {
		{'default:lapis', 'default:lapis', 'default:lapis'},
		{'default:lapis', 'default:lapis', 'default:lapis'},
		{'default:lapis', 'default:lapis', 'default:lapis'},
	}
})

minetest.register_craft({
	output = 'default:lapis 9',
	recipe = {
		{'default:lapisblock'},
	}
})

minetest.register_craft({
	output = 'default:emeraldblock',
	recipe = {
		{'default:emerald', 'default:emerald', 'default:emerald'},
		{'default:emerald', 'default:emerald', 'default:emerald'},
		{'default:emerald', 'default:emerald', 'default:emerald'},
	}
})

minetest.register_craft({
	output = 'default:emerald 9',
	recipe = {
		{'default:emeraldblock'},
	}
})

minetest.register_craft({
	output = 'default:pick_ruby',
	recipe = {
		{'default:ruby', 'default:ruby', 'default:ruby'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_lapis',
	recipe = {
		{'default:lapis', 'default:lapis', 'default:lapis'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_emerald',
	recipe = {
		{'default:emerald', 'default:emerald', 'default:emerald'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_ruby',
	recipe = {
		{'default:ruby'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_lapis',
	recipe = {
		{'default:lapis'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:shovel_emerald',
	recipe = {
		{'default:emerald'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_ruby',
	recipe = {
		{'default:ruby', 'default:ruby'},
		{'default:ruby', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_lapis',
	recipe = {
		{'default:lapis', 'default:lapis'},
		{'default:lapis', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_emerald',
	recipe = {
		{'default:emerald', 'default:emerald'},
		{'default:emerald', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_ruby',
	recipe = {
		{'default:ruby'},
		{'default:ruby'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_lapis',
	recipe = {
		{'default:lapis'},
		{'default:lapis'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:sword_emerald',
	recipe = {
		{'default:emerald'},
		{'default:emerald'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:paper 5',
	recipe = {
		{'group:tree', 'group:tree', 'group:tree'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "default:note",
	recipe = {"default:paper",},
})

minetest.register_craft({
	output = 'default:bowl_empty',
	recipe = {
		{'', '', ''},
		{'group:stone', '', 'group:stone'},
		{'', 'group:stone', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bowl_soup",
	recipe = {"default:bowl_empty", "kpgmobs:beef","flowers:mushroom_brown"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bowl_soup",
	recipe = {"default:bowl_empty", "kpgmobs:deermeat","flowers:mushroom_brown"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bowl_soup",
	recipe = {"default:bowl_empty", "mobs:pork_cooked","flowers:mushroom_brown"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bowl_soup",
	recipe = {"default:bowl_empty", "mobs:chicken_cooked","flowers:mushroom_brown"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bowl_soup",
	recipe = {"default:bowl_empty", "mobs:mobs:meat","flowers:mushroom_brown"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:bowl_cereal",
	recipe = {"default:bowl_empty", "farming:wheat"},
})

minetest.register_craft({
	output = 'default:barrel',
	recipe = {
		{'', 'group:wood', ''},
		{'group:wood', '', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	output = 'default:lunablock',
	recipe = {
		{'default:luna', 'default:luna', 'default:luna'},
		{'default:luna', 'default:luna', 'default:luna'},
		{'default:luna', 'default:luna', 'default:luna'},
	}
})

minetest.register_craft({
	output = 'default:luna 9',
	recipe = {
		{'default:lunablock'},
	}
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:stick",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:pick_wood",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:shovel_wood",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:axe_wood",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:sword_wood",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:book",
	burntime = 5,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:paper",
	burntime = 3,
})

minetest.register_craft({
	type = "fuel",
	recipe = "doors:door_wood",
	burntime = 17,
})

minetest.register_craft({
	type = "fuel",
	recipe = "trash_can:trash_can_wooden",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "beds:fancy_bed",
	burntime = 25,
})

minetest.register_craft({
	type = "fuel",
	recipe = "group:wool",
	burntime = 10,
})

minetest.register_craft({
	type = "shapeless",
	output = "default:dirt_with_grass",
	recipe = {"default:dirt", "group:grass"}
})

minetest.register_craft({
	type = "shapeless",
	output = "mobs:chicken",
	recipe = {"group:grass", "mobs:egg"}
})

minetest.register_craft({
	output = 'unified_inventory:bag_large',
	recipe = {
		{'group:wool', 'group:wool', ''},
		{'group:wool', 'group:wool', ''},
		{'group:wool', 'group:wool', ''},
	}
})

minetest.register_craft({
	output = 'default:pick_gold',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_gold',
	recipe = {
		{'default:gold_ingot'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_gold',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot'},
		{'default:gold_ingot', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_gold',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot'},
		{'group:stick', 'default:gold_ingot'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:sword_gold',
	recipe = {
		{'default:gold_ingot'},
		{'default:gold_ingot'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:string 4',
	recipe = {
		{'group:wool'},
	}
})

minetest.register_craft({
	output = 'default:pick_dirt',
	recipe = {
		{'default:dirt', 'default:dirt', 'default:dirt'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_dirt',
	recipe = {
		{'default:dirt'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_dirt',
	recipe = {
		{'default:dirt', 'default:dirt'},
		{'default:dirt', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_dirt',
	recipe = {
		{'default:dirt', 'default:dirt'},
		{'group:stick', 'default:dirt'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:sword_dirt',
	recipe = {
		{'default:dirt'},
		{'default:dirt'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:lamp',
	recipe = {
		{'default:glass', 'default:glass', 'default:glass'},
		{'default:glass', 'xdecor:lantern', 'default:glass'},
		{'default:glass', 'default:glass', 'default:glass'},
	}
})

minetest.register_craft({
	output = "default:coalstone_tile 4",
	recipe = {
		{"default:charcoal_lump", "default:charcoal_lump"},
		{"default:charcoal_lump", "default:cobble"}
	}
})

minetest.register_craft({
	output = 'default:quartsf',
	recipe = {
		{'default:quarts', 'default:quarts', 'default:quarts'},
		{'default:quarts', 'default:quarts', 'default:quarts'},
		{'default:quarts', 'default:quarts', 'default:quarts'},
	}
})

minetest.register_craft({
	output = 'quartsb',
	recipe = {
		{'default:quartsf', 'default:quartsf', 'default:quartsf'},
		{'default:quartsf', 'default:quartsf', 'default:quartsf'},
		{'default:quartsf', 'default:quartsf', 'default:quartsf'},
	}
})

minetest.register_craft({
	output = 'default:axe_emerald',
	recipe = {
		{'default:emerald', 'default:emerald'},
		{'group:stick', 'default:emerald'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:axe_ruby',
	recipe = {
		{'default:ruby', 'default:ruby'},
		{'group:stick', 'default:ruby'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:axe_lapis',
	recipe = {
		{'default:lapis', 'default:lapis'},
		{'group:stick', 'default:lapis'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:pick_q',
	recipe = {
		{'default:quartsb', 'default:quartsb', 'default:quartsb'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_q',
	recipe = {
		{'default:quartsb'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_q',
	recipe = {
		{'default:quartsb', 'default:quartsb'},
		{'default:quartsb', 'default:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_q',
	recipe = {
		{'default:quartsb', 'default:quartsb'},
		{'group:stick', 'default:quartsb'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:sword_q',
	recipe = {
		{'default:quartsb'},
		{'default:quartsb'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:nyancat_rainbow',
	recipe = {
		{'default:rainbowshards', 'default:rainbowshards', 'default:rainbowshards'},
		{'default:rainbowshards', 'default:rainbowshards', 'default:rainbowshards'},
		{'default:rainbowshards', 'default:rainbowshards', 'default:rainbowshards'},
	}
})

minetest.register_craft({
	output = 'default:rainbowshards 9',
	recipe = {
		{'default:nyancat_rainbow'},
	}
})

minetest.register_craft({
	output = 'default:pick_rs',
	recipe = {
		{'default:rainbowshards', 'default:rainbowshards', 'default:rainbowshards'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:shovel_rs',
	recipe = {
		{'default:rainbowshards'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_rs',
	recipe = {
		{'default:rainbowshards', 'default:rainbowshards'},
		{'default:rainbowshards', 'default:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_rs',
	recipe = {
		{'default:rainbowshards', 'default:rainbowshards'},
		{'group:stick', 'default:rainbowshards'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'default:sword_rs',
	recipe = {
		{'default:rainbowshards'},
		{'default:rainbowshards'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:axe_soul',
	recipe = {
		{'default:soul', 'default:soul'},
		{'group:stick', 'default:soul'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:quartsf 9',
	recipe = {
		{'default:quartsb'},
	}
})

minetest.register_craft({
	output = 'default:quarts 9',
	recipe = {
		{'default:quartsf'},
	}
})

minetest.register_craft({
	output = 'default:flintstone',
	recipe = {
		{'default:flint', 'default:flint', 'default:flint'},
		{'default:flint', 'default:flint', 'default:flint'},
		{'default:flint', 'default:flint', 'default:flint'},
	}
})

minetest.register_craft({
	output = 'default:flint 9',
	recipe = {
		{'default:flintstone'},
	}
})

minetest.register_craft({
	output = 'default:giftpaper',
	recipe = {
		{'', 'dye:red', ''},
		{'', 'default:paper', ''},
		{'', '', ''},
	}
})

minetest.register_craft({
	output = 'default:gift',
	recipe = {
		{'default:giftpaper', 'default:giftpaper', 'default:giftpaper'},
		{'default:giftpaper', 'default:chest', 'default:giftpaper'},
		{'default:giftpaper', 'default:giftpaper', 'default:giftpaper'},
	}
})

minetest.register_craft({
	output = 'default:fridge',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', '', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
	}
})

minetest.register_craft({
	output = 'default:club',
	recipe = {
		{'', 'group:tree', ''},
		{'', 'group:tree', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'default:spikeclub',
	recipe = {
		{'', 'default:steel_ingot', ''},
		{'default:steel_ingot', 'default:club', 'default:steel_ingot'},
		{'', 'default:steel_ingot', ''},
	}
})

minetest.register_craft({
	output = 'default:eyed',
	recipe = {
		{'default:eye', 'default:eye', 'default:eye'},
		{'default:eye', 'default:glass', 'default:eye'},
		{'default:eye', 'default:eye', 'default:eye'},
	}
})

minetest.register_craft({
	output = 'default:giantapple',
	recipe = {
		{'default:apple', 'default:apple', 'default:apple'},
		{'default:apple', 'default:apple', 'default:apple'},
		{'default:apple', 'default:apple', 'default:apple'},
	}
})

minetest.register_craft({
	output = 'default:apple 9',
	recipe = {
		{'default:giantapple'},
	}
})

minetest.register_craft({
	output = 'default:giantstrawberry',
	recipe = {
		{'default:strawberry', 'default:strawberry', 'default:strawberry'},
		{'default:strawberry', 'default:strawberry', 'default:strawberry'},
		{'default:strawberry', 'default:strawberry', 'default:strawberry'},
	}
})

minetest.register_craft({
	output = 'default:strawberry 9',
	recipe = {
		{'default:giantstrawberry'},
	}
})

minetest.register_craft({
	output = 'default:dirtcobble',
	recipe = {
		{'default:dirt', 'default:dirt'},
		{'default:dirt', 'default:dirt'},
	}
})

minetest.register_craft({
	output = 'default:dirt 4',
	recipe = {
		{'default:dirtcobble'},
	}
})

minetest.register_craft({
	output = 'default:snowcobble',
	recipe = {
		{'default:snowblock', 'default:snowblock'},
		{'default:snowblock', 'default:snowblock'},
	}
})

minetest.register_craft({
	output = 'default:snowblock 4',
	recipe = {
		{'default:snowcobble'},
	}
})

minetest.register_craft({
	output = 'default:ladder_gold 10',
	recipe = {
		{'default:gold_ingot', '', 'default:gold_ingot'},
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
		{'default:gold_ingot', '', 'default:gold_ingot'},
	}
})

minetest.register_craft({
	output = 'default:ladder_ice 10',
	recipe = {
		{'default:ice', '', 'default:ice'},
		{'default:ice', 'default:ice', 'default:ice'},
		{'default:ice', '', 'default:ice'},
	}
})

minetest.register_craft({
	output = 'default:sandcobble',
	recipe = {
		{'default:sand', 'default:sand'},
		{'default:sand', 'default:sand'},
	}
})

minetest.register_craft({
	output = 'default:sand 4',
	recipe = {
		{'default:sandcobble'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "default:cookedcati",
	recipe = "default:cactus",
})

minetest.register_craft({
	type = "shapeless",
	output = "default:applepieraw",
	recipe = {"farming:flour", "default:apple", "farming:sugar"}
})

minetest.register_craft({
	type = "cooking",
	output = "default:cookedapplepie",
	recipe = "default:applepieraw",
})

minetest.register_craft({
	output = 'default:dclay_lump 4',
	recipe = {
		{'default:dclay'},
	}
})

minetest.register_craft({
	output = 'default:dclay',
	recipe = {
		{'default:dclay_lump', 'default:dclay_lump'},
		{'default:dclay_lump', 'default:dclay_lump'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "default:dclay_brick",
	recipe = "default:dclay_lump",
})

minetest.register_craft({
	output = 'default:brick2',
	recipe = {
		{'default:dclay_brick', 'default:dclay_brick'},
		{'default:dclay_brick', 'default:dclay_brick'},
	}
})

minetest.register_craft({
	output = 'default:dclay_brick 4',
	recipe = {
		{'default:brick2'},
	}
})

minetest.register_craft({
	output = 'default:chest_locked',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:wood', 'default:steel_ingot', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "default:water_source",
	recipe = "default:icy",
})

minetest.register_craft({
	type = "cooking",
	output = "default:water_source",
	recipe = "default:ice",
})

minetest.register_craft({
	type = "cooking",
	output = "default:water_source",
	recipe = "default:icep",
})

minetest.register_craft({
	type = "cooking",
	output = "default:river_water_source",
	recipe = "default:snow",
})

minetest.register_craft({
	type = "cooking",
	output = "default:river_water_source",
	recipe = "default:snowblock",
})

minetest.register_craft({
	type = "cooking",
	output = "default:river_water_source",
	recipe = "default:dirt_with_snow",
})

minetest.register_craft({
	type = "shapeless",
	output = "default:mud",
	recipe = {"default:dirt", "default:water_source"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:mud",
	recipe = {"default:dirt", "default:river_water_source"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:mudwater_source 5'",
	recipe = {"default:mud", "default:water_source"},
})

minetest.register_craft({
	type = "shapeless",
	output = "default:mudwater_source 5'",
	recipe = {"default:mud", "default:river_water_source"},
})

minetest.register_craft({
	type = "cooking",
	output = "ethereal:crystal_ingot",
	recipe = "ethereal:crystal_spike",
})

minetest.register_craft({
	output = 'default:hedge',
	recipe = {
		{'group:leaves', 'group:leaves'},
		{'group:leaves', 'group:leaves'},
	}
})