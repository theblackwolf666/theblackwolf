--Craftitems

minetest.register_craftitem("nkwings:earth_wings_activatedb", {
	description = "Earth Essence Wings",
	inventory_image = "winginv2.png",
	stack_max = 1,
	on_use = function(itemstack, user, pointed_thing)
		local name = user:get_player_name()
		local privs = minetest.get_player_privs(name)
		privs.fly = not privs.fly
		privs.fast = not privs.fast
		minetest.set_player_privs(name, privs)
		minetest.sound_play("wings") to_player = (name)
		itemstack:take_item()
        return itemstack
	end,
})