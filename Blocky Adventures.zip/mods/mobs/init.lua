-- Mob Api

dofile(minetest.get_modpath("mobs").."/api.lua")

-- Animals

dofile(minetest.get_modpath("mobs").."/warthog.lua") -- KrupnoPavel
dofile(minetest.get_modpath("mobs").."/bunny.lua") -- ExeterDad
dofile(minetest.get_modpath("mobs").."/kitten.lua") -- Jordach/BFD

-- Monsters

dofile(minetest.get_modpath("mobs").."/sandmonster.lua")
dofile(minetest.get_modpath("mobs").."/treemonster.lua")
dofile(minetest.get_modpath("mobs").."/lava_flan.lua") -- Zeg9

-- NPC

dofile(minetest.get_modpath("mobs").."/npc.lua") -- TenPlus1

-- Meat & Cooked Meat

minetest.register_craftitem("mobs:meat_raw", {
	description = "Raw Rabbit Meat",
	inventory_image = "mobs_meat_raw.png",
	on_use = minetest.item_eat(3),
})

minetest.register_craftitem("mobs:meat", {
	description = "Cooked Rabbit",
	inventory_image = "mobs_meat.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:meat",
	recipe = "mobs:meat_raw",
	cooktime = 5,
})

-- Golden Lasso

minetest.register_tool("mobs:magic_lasso", {
	description = "Magic Lasso (right-click animal to put in inventory)",
	inventory_image = "mobs_magic_lasso.png",
})

minetest.register_craft({
	output = "mobs:magic_lasso",
	recipe = {
		{"farming:string", "default:gold_lump", "farming:string"},
		{"default:gold_lump", "default:gold_lump", "default:gold_lump"},
		{"farming:string", "default:gold_lump", "farming:string"},
	}
})

if minetest.setting_get("log_mods") then
	minetest.log("action", "mobs loaded")
end
