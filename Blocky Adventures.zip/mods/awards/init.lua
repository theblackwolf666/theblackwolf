-- AWARDS
--
-- Copyright (C) 2013-2015 rubenwardy
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU Lesser General Public License as published by
-- the Free Software Foundation; either version 2.1 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU Lesser General Public License for more details.
-- You should have received a copy of the GNU Lesser General Public License along
-- with this program; if not, write to the Free Software Foundation, Inc.,
-- 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
--

local S
if (intllib) then
	dofile(minetest.get_modpath("intllib").."/intllib.lua")
	S = intllib.Getter(minetest.get_current_modname())
else
	S = function ( s ) return s end
end

dofile(minetest.get_modpath("awards").."/api.lua")
dofile(minetest.get_modpath("awards").."/chat_commands.lua")
dofile(minetest.get_modpath("awards").."/sfinv.lua")
dofile(minetest.get_modpath("awards").."/unified_inventory.lua")
dofile(minetest.get_modpath("awards").."/triggers.lua")
awards.set_intllib(S)

-- This award can't be part of Unified Inventory, it would make a circular dependency
if minetest.get_modpath("unified_inventory") then
	awards.register_achievement("awards_ui_bags", {
		title = S("Backpacker"),
		description = S("Craft A Backpack."),
		icon = "bags_backpack.png",
		trigger = {
			type = "craft",
			item = "unified_inventory:bag_large",
			target = 1
		}
	})

	awards.register_achievement("awards_stonebrick", {
		title = S("Outpost"),
		description = S("Craft 25 stone bricks."),
		icon = "default_stone_brick.png",
		trigger = {
			type = "craft",
			item = "default:stonebrick",
			target = 25
		}
	})

	awards.register_achievement("awards_desert_stonebrick", {
		title = S("Desert Dweller"),
		description = S("Craft 25 desert stone bricks."),
		icon = "default_desert_stone_brick.png",
		trigger = {
			type = "craft",
			item = "default:desert_stonebrick",
			target = 25
		}
	})

	awards.register_achievement("awards_desertstonebrick", {
		title = S("Welcome To Egypt"),
		description = S("Craft a Pyramid with 50 sandstone bricks."),
		icon = "default_sandstone_brick.png",
		trigger = {
			type = "place",
			node = "default:sandstonebrick",
			target = 50
		}
	})

	awards.register_achievement("awards_bookshelf", {
		title = S("Little Library"),
		description = S("Craft 3 Bookshelves."),
		icon = "default_bookshelf.png",
		trigger = {
			type = "craft",
			item = "default:bookshelf",
			target = 3
		}
	})

	-- Obsessed with Obsidian
	awards.register_achievement("award_obsessed_with_obsidian",{
		title = S("Obsessed With Obsidian"),
		description = S("Mine 10 Obsidian."),
		icon = "default_obsidian.png",
		trigger = {
			type = "dig",
			node = "default:obsidian",
			target = 10
		}
	})

	-- On the way
	awards.register_achievement("award_on_the_way", {
		title = S("Rail Way"),
		description = S("Place 64 rails."),
		icon = "default_rail.png",
		trigger = {
			type = "place",
			node = "default:rail",
			target = 64		}
	})

	-- Lumberjack
	awards.register_achievement("award_lumberjack", {
	title = S("Lumberjack"),
		description = S("Enter A Pine Forest And Chop 100 Trees."),
		icon = "default_pine_tree.png",
		trigger = {
			type = "dig",
			node = "default:pine_tree",
			target = 100
		}
	})

	-- Found a Nyan cat!
	awards.register_achievement("award_nyanfind", {
		title = S("Found A Nyan cat"),
		description = S("Collect a Nyan cat's rainbow."),
		icon = "default_nc_front.png",
		trigger = {
			type = "dig",
			node = "default:nyancat_rainbow",
			target = 1
		}
	})

	-- Mini Miner
	awards.register_achievement("award_mine2", {
		title = S("The Miner"),
		description = S("Dig 100 stone blocks."),
		icon = "default_stone.png",
		background = "awards_bg_mining.png",
		trigger = {
			type = "dig",
			node = "default:stone",
			target = 100		}
	})

	-- Marchand de sable
	awards.register_achievement("award_marchand_de_sable", {
		title = S("The Sand Man"),
		description = S("Dig 1,000 sand."),
		icon = "default_sand.png",
		background = "awards_bg_mining.png",
		trigger = {
			type = "dig",
			node = "default:sand",
			target = 1000
		}
	})

	awards.register_achievement("awards_crafter_of_sticks", {
		title = S("The Stick Master"),
		description = S("Craft 100 sticks."),
		icon = "default_stick.png",
		trigger = {
			type = "craft",
			item = "default:stick",
			target = 100
		}
	})

	awards.register_achievement("awards_cactus", {
		title = S("Desert Discoverer"),
		description = S("Collect your first cactus."),
		icon = "default_cactus_side.png",
		trigger = {
			type = "dig",
			node = "default:cactus",
			target = 1
		}
	})

	-- Proof that player visited snowy lands
	awards.register_achievement("awards_snowblock", {
		title = S("Very Simple Snow Man"),
		description = S("Place two snow blocks."),
		icon = "default_snow.png",
		trigger = {
			type = "place",
			node = "default:snowblock",
			target = 2
		}
	})

	awards.register_achievement("awards_gold_ore", {
		title = S("It's Gold"),
		description = S("Mine your first gold ore."),
		icon = "default_gold_lump.png",
		background = "awards_bg_mining.png",
		trigger = {
			type = "dig",
			node = "default:stone_with_gold",
			target = 1
		}
	})

	awards.register_achievement("awards_gold_rush", {
		title = S("Gold Rush"),
		description = S("Mine 50 gold ores."),
		icon = "default_gold_lump.png",
		background = "awards_bg_mining.png",
		trigger = {
			type = "dig",
			node = "default:stone_with_gold",
			target = 50
		}
	})

	awards.register_achievement("awards_diamond_ore", {
		title = S("Wow, I has Diamond!"),
		description = S("Mine your first diamond ore."),
		icon = "default_diamond.png",
		trigger = {
			type = "dig",
			node = "default:stone_with_diamond",
			target = 1
		}
	})

	awards.register_achievement("awards_diamondblock", {
		title = S("Hardest Block on Earth"),
		description = S("Craft a diamond block."),
		icon = "default_diamond_block.png",
		trigger = {
			type = "craft",
			item = "default:diamondblock",
			target = 1
		}
	})

	awards.register_achievement("awards_mossycobble", {
		title = S("Into the Dungeon"),
		description = S("Mine a mossy cobblestone."),
		icon = "default_mossycobble.png",
		trigger = {
			type = "dig",
			node = "default:mossycobble",
			target = 1
		}
	})

	awards.register_achievement("award_furnace", {
		title = S("The Smelter"),
		description = S("Craft 1 Furnace."),
		icon = "default_furnace_front.png",
		trigger = {
			type = "craft",
			item= "default:furnace",
			target = 1
		}
	})

	awards.register_achievement("award_chest", {
		title = S("Treasure"),
		description = S("Craft 1 chest."),
		icon = "default_chest_front.png",
		trigger = {
			type = "craft",
			item= "default:chest",
			target = 1
		}
	})

	awards.register_achievement("award_chest2", {
		title = S("Pirate"),
		description = S("Craft 10 chests."),
		icon = "default_chest_front.png",
		trigger = {
			type = "craft",
			item= "default:chest",
			target = 10
		}
	})

	awards.register_achievement("award_steelladder", {
		title = S("Set Up A Base"),
		description = S("Make a cobble wall of 40."),
		icon = "default_wall.png",
		trigger = {
			type = "place",
			node = "walls:cobble",
			target = 40
		}
	})
end

if minetest.get_modpath("vessels") then
	awards.register_achievement("award_vessels_shelf", {
		title = S("Shiny"),
		icon = "default_glass.png",
		description = S("Craft 25 glass blocks from sand."),
		trigger = {
			type = "craft",
			item= "default:glass",
			target = 25
		}
	})
end

if minetest.get_modpath("farming") then
	awards.register_achievement("awards_farmer", {
		title = S("Farm Hand"),
		description = S("Harvest a fully grown wheat plant."),
		icon = "farming_wheat_8.png",
		trigger = {
			type = "dig",
			node = "farming:wheat_8",
			target = 1
		}
	})
	awards.register_achievement("awards_farmer2", {
		title = S("Field Worker"),
		description = S("Harvest 30 fully grown wheat plants."),
		icon = "farming_wheat_8.png",
		trigger = {
			type = "dig",
			node = "farming:wheat_8",
			target = 30
		}
	})

	awards.register_achievement("awards_farmer3", {
		title = S("Aspiring Farmer"),
		description = S("Harvest 100 fully grown wheat plants."),
		icon = "farming_wheat_8.png",
		trigger = {
			type = "dig",
			node = "farming:wheat_8",
			target = 100
		}
	})
end

if minetest.get_modpath("beds") then
	awards.register_achievement("award_bed", {
		title = S("Getting Comfy"),
		description = S("Craft a bed."),
		icon = "beds_bed.png",
		trigger = {
			type = "craft",
			item= "beds:steel_bed",
			target = 1
		}
	})
end

if minetest.get_modpath("default") then
	-- Dig it up
	awards.register_achievement("award_dirt",{
		title = S("Dig It Up"),
		description = S("Collect your first dirt."),
		icon = "default_dirt.png",
		trigger = {
			type = "dig",
			node = "default:dirt",
			target = 1
		}
	})
end

if minetest.get_modpath("default") then
	-- Digging Lots
	awards.register_achievement("award_dirt2",{
		title = S("Digging Lots"),
		description = S("Collect 30 Grass blocks."),
		icon = "default_grass_side.png",
		trigger = {
			type = "dig",
			node = "default:dirt_with_grass",
			target = 30
		}
	})
end

if minetest.get_modpath("default") then
	-- Return To Normal
	awards.register_achievement("award_dirt3",{
		title = S("Return To Green"),
		description = S("Craft & Return Dirt Back To Grass."),
		icon = "default_grass_side.png",
		trigger = {
			type = "craft",
			item = "default:dirt_with_grass",
			target = 1
		}
	})
end

if minetest.get_modpath("default") then
awards.register_achievement("awards_explore", {
		title = S("Desert Explorer"),
		description = S("Collect A Piece Of Desert Stone."),
		icon = "default_desert_stone.png",
		trigger = {
			type = "dig",
			node = "default:desert_stone",
			target = 1
		}
	})
end

-- Flowers
	awards.register_achievement("award_flowers", {
	title = S("It's Pretty"),
		description = S("Pick Up A Rose."),
		icon = "flowers_rose.png",
		trigger = {
			type = "dig",
			node = "flowers:rose",
			target = 1
		}
	})

-- Prickly
	awards.register_achievement("award_prickly", {
	title = S("Careful Hands"),
		description = S("Pick Up 25 Pieces Of Cactus."),
            icon = "default_cactus_side.png",
      		trigger = {
			type = "dig",
			node = "default:cactus",
			target = 25
		}
	})

-- Emeralds
	awards.register_achievement("award_emeralds", {
	title = S("Found An Emerald"),
		description = S("Mine Emerald."),
            icon = "default_emerald.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_emerald",
			target = 1
		}
	})

-- Ruby
	awards.register_achievement("award_rubies", {
	title = S("Found A Ruby"),
		description = S("Mine Ruby."),
            icon = "default_ruby.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_ruby",
			target = 1
		}
	})

-- Sapphire
	awards.register_achievement("award_sapphire", {
	title = S("Found Sapphire"),
		description = S("Mine Sapphire."),
            icon = "default_lapis.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_lapis",
			target = 1
		}
	})

-- Silver
	awards.register_achievement("award_silver", {
	title = S("Found Silver"),
		description = S("Mine Silver."),
            icon = "default_iron_lump.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_iron",
			target = 1
		}
	})

-- Copper
	awards.register_achievement("award_copper", {
	title = S("Found Copper"),
		description = S("Mine Copper."),
            icon = "default_copper_lump.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_copper",
			target = 1
		}
	})

-- Coal
	awards.register_achievement("award_coal", {
	title = S("Found Coal"),
		description = S("Mine Coal."),
            icon = "default_coal_lump.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_coal",
			target = 1
		}
	})

-- Lunar
	awards.register_achievement("award_lunar", {
	title = S("Pretty Lunar Chunk"),
		description = S("Dig Up Lunar From Sand."),
            icon = "default_luna.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_luna",
			target = 1
		}
	})

-- Lunar2
	awards.register_achievement("award_lunar2", {
	title = S("Lots Of Lunar"),
		description = S("Dig Up 100 Lunar Chunks From Sand."),
            icon = "default_luna.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_luna",
			target = 100
		}
	})

-- Quartz
	awards.register_achievement("award_quartz", {
	title = S("Found A Quartz Piece"),
		description = S("Mine Quartz."),
            icon = "default_quartz_piece.png",
      		trigger = {
			type = "dig",
			node = "default:quartso",
			target = 1
		}
	})

-- Coal2
	awards.register_achievement("award_coal2", {
	title = S("Smutty Hands"),
		description = S("Mine 35 Pieces Of Coal."),
            icon = "default_coal_lump.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_coal",
			target = 35
		}
	})

-- Digdug
	awards.register_achievement("award_digdug", {
	title = S("Dig Dug"),
		description = S("Dig Through 1000 Pieces Of Grass Blocks!"),
            icon = "default_grass_side.png",
      		trigger = {
			type = "dig",
			node = "default:dirt_with_grass",
			target = 1000
		}
	})

-- Craft Club
	awards.register_achievement("award_club", {
	title = S("Dungeon Masters"),
		description = S("Craft A Classic Club!"),
            icon = "default_club.png",
      		trigger = {
			type = "craft",
			item = "default:club",
			target = 1
		}
	})

-- Posted
	awards.register_achievement("award_posted", {
	title = S("Posted!"),
		description = S("Craft A Wooden Sign!"),
            icon = "default_sign_wood.png",
      		trigger = {
			type = "craft",
			item = "default:sign_wall_wood",
			target = 1
		}
	})

-- Craft Candles
	awards.register_achievement("award_candles", {
	title = S("Pretty Lights"),
		description = S("Craft A Set Of 50 Lunar Candles!"),
            icon = "default_torch_on_floor.png",
      		trigger = {
			type = "craft",
			item = "default:torch",
			target = 50
		}
	})

-- Bucket
	awards.register_achievement("award_bucket", {
	title = S("Scoop It Up"),
		description = S("Craft A Bucket To Gather Liquids!"),
            icon = "bucket.png",
      		trigger = {
			type = "craft",
			item = "bucket:bucket_empty",
			target = 1
		}
	})

-- Putaway
	awards.register_achievement("award_putaway", {
	title = S("Throw It Away"),
		description = S("Create A Useful Trashcan"),
            icon = "dumpster_wield.png",
      		trigger = {
			type = "craft",
			item = "trash_can:trash_can_wooden",
			target = 1
		}
	})

-- Bomberman
	awards.register_achievement("award_bomberman", {
	title = S("Bomberman"),
		description = S("Craft 25 Bombs"),
            icon = "tnt_side.png",
      		trigger = {
			type = "craft",
			item = "tnt:tnt",
			target = 25
		}
	})

-- Diver
	awards.register_achievement("award_diver", {
	title = S("The Diver"),
		description = S("Craft A Scuba Helmet To Explore The Seas Safely"),
            icon = "scuba_item.png",
      		trigger = {
			type = "craft",
			item = "scuba:scuba_helmet",
			target = 1
		}
	})

-- Nametag
	awards.register_achievement("award_nametag", {
	title = S("You Name It"),
		description = S("Create A Nametag"),
            icon = "nametag_tag.png",
      		trigger = {
			type = "craft",
			item = "nametag:tag",
			target = 1
		}
	})

-- Showitoff
	awards.register_achievement("award_showit", {
	title = S("Show It Off"),
		description = S("Craft An Item Frame To Show Your Items Off"),
            icon = "default_frame.png",
      		trigger = {
			type = "craft",
			item = "itemframes:frame",
			target = 1
		}
	})

-- Muddy
	awards.register_achievement("award_mud", {
	title = S("Playing With Mud"),
		description = S("Dig Into Some Mud"),
            icon = "default_mud.png",
      		trigger = {
			type = "dig",
			node = "default:mud",
			target = 1
		}
	})

-- Swordtime
	awards.register_achievement("award_swordtime", {
	title = S("The Toy Knight"),
		description = S("Craft Your Self A Basic Wooden Sword"),
            icon = "default_tool_woodsword.png",
      		trigger = {
			type = "craft",
			item = "default:sword_wood",
			target = 1
		}
	})

-- Shoveltime
	awards.register_achievement("award_shoveltime", {
	title = S("Let's Get Diggy With It"),
		description = S("Craft Your Self A Basic Wooden Shovel"),
            icon = "default_tool_woodshovel.png",
      		trigger = {
			type = "craft",
			item = "default:shovel_wood",
			target = 1
		}
	})

-- Picktime
	awards.register_achievement("award_picktime", {
	title = S("Time To Find A Cave"),
		description = S("Craft Your Self A Basic Wooden Pick"),
            icon = "default_tool_woodpick.png",
      		trigger = {
			type = "craft",
			item = "default:pick_wood",
			target = 1
		}
	})

-- Axetime
	awards.register_achievement("award_axetime", {
	title = S("It's Chopping Time"),
		description = S("Craft Your Self A Basic Wooden Axe"),
            icon = "default_tool_woodaxe.png",
      		trigger = {
			type = "craft",
			item = "default:axe_wood",
			target = 1
		}
	})

-- Planttime
	awards.register_achievement("award_planttime", {
	title = S("Let's Make A Garden"),
		description = S("Craft Your Self A Basic Wooden Hoe"),
            icon = "farming_tool_woodhoe.png",
      		trigger = {
			type = "craft",
			item = "farming:hoe_wood",
			target = 1
		}
	})

-- Firstcandle
	awards.register_achievement("award_firstcandle", {
	title = S("Light It Up"),
		description = S("Craft Some Lunar Candles Using A Stick And Lunar Chunks You Find In Sand On Beaches"),
            icon = "default_torchy.png",
      		trigger = {
			type = "craft",
			item = "default:torch",
			target = 4
		}
	})

-- Goldenladder
	awards.register_achievement("award_goldladder", {
	title = S("Greed"),
		description = S("Use Gold Bars To Create Golden Ladders,     Yes, Seriously"),
            icon = "default_ladder_gold.png",
      		trigger = {
			type = "craft",
			item = "default:ladder_gold",
			target = 1
		}
	})