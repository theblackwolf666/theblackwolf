Copyright (C) 2010-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/


Sealamps: almost completely based on the torch code from minetest/games/minetest_game/mods/default/nodes.lua


Sounds:
sounds = default.node_sound_defaults()


.png's:
Sealamps torch .png's are (based (only the colors are slightly adjusted) on) VanessaE's animated torches (WTFPL):
- default_torch_animated.png
- default_torch_on_ceiling_animated.png
- default_torch_on_floor_animated.png
- default_torch_on_floor.png

Code:
minetest/games/minetest_game/mods/default/nodes.lua --> torch

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>
GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.