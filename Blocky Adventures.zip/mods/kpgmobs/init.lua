dofile(minetest.get_modpath("kpgmobs").."/api.lua")

minetest.register_craftitem("kpgmobs:beef_raw", {
	description = "Raw Beef",
	inventory_image = "mobs_beef_raw.png",
})

minetest.register_craftitem("kpgmobs:beef", {
	description = "Grilled Beef",
	inventory_image = "mobs_beef.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craftitem("kpgmobs:deer_raw", {
	description = "Raw Deer Meat",
	inventory_image = "mobs_deermeat_raw.png",
})

minetest.register_craftitem("kpgmobs:deermeat", {
	description = "Cooked Deer Meat",
	inventory_image = "mobs_deermeat.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craft({
	type = "cooking",
	output = "kpgmobs:meat",
	recipe = "kpgmobs:meat_raw",
	cooktime = 8,
})

minetest.register_craft({
	type = "cooking",
	output = "kpgmobs:beef",
	recipe = "kpgmobs:beef_raw",
	cooktime = 6,
})

minetest.register_craft({
	type = "cooking",
	output = "kpgmobs:deermeat",
	recipe = "kpgmobs:deer_raw",
	cooktime = 7,
})

kpgmobs:register_mob("kpgmobs:deer", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"mobs_deer.png"},
	visual = "mesh",
      light_source = 3,
	mesh = "mobs_deer2.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "kpgmobs:deer_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		stand_start = 25,
		stand_end = 75,
		walk_start = 75,
		walk_end = 100,
	},
	follow = "farming:wheat",
	view_range = 5,
	
	
})
kpgmobs:register_spawn("kpgmobs:deer", {"default:dirt_with_snow"}, 20, 8, 9000, 1, 31000)

kpgmobs:register_mob("kpgmobs:medved", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"mobs_medved.png"},
	visual = "mesh",
      light_source = 3,
	mesh = "mobs_medved.x",
	makes_footstep_sound = true,
	view_range = 7,
	walk_velocity = 1,
	run_velocity = 2,
	damage = 10,
	armor = 200,
	attack_type = "dogfight",
	drops = {
		{name = "kpgmobs:meat_raw",
		chance = 0,
		min = 0,
		max = 0,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,

	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 30,
		walk_start = 35,
		walk_end = 65,
		run_start = 105,
		run_end = 135,
		punch_start = 70,
		punch_end = 100,
	},
})
kpgmobs:register_spawn("kpgmobs:medved", {"group:stone"}, 20, 0, 11000, 3, 31000)

kpgmobs:register_mob("kpgmobs:cow", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"mobs_cow.png"},
	visual = "mesh",
      light_source = 3,
	mesh = "mobs_cow.x",
	makes_footstep_sound = true,
	view_range = 7,
	walk_velocity = 1,
	run_velocity = 2,
	damage = 10,
	armor = 200,
	drops = {
		{name = "kpgmobs:beef_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
      sounds = {
      random = "mobs_cow",
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
    follow = "farming:wheat",
	view_range = 5,
	-- ADDED TenPlus1 (right-clicking cow with empty bucket gives bucket of milk and moo sound)
	on_rightclick = function(self, clicker)
		tool = clicker:get_wielded_item():get_name()
		if tool == "bucket:bucket_empty" then
			if self.milked then
				minetest.sound_play("cow", {
					object = self.object,
					gain = 1.0, -- default
					max_hear_distance = 32, -- default
					loop = false,
				})
				do return end
			end
			clicker:get_inventory():remove_item("main", "bucket:bucket_empty")
			clicker:get_inventory():add_item("main", "kpgmobs:bucket_milk")
			if math.random(1,2) > 1 then self.milked = true	end
		end
	end,


	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 30,
		walk_start = 35,
		walk_end = 65,
		run_start = 105,
		run_end = 135,
		punch_start = 70,
		punch_end = 100,
	},
})
kpgmobs:register_spawn("kpgmobs:cow", {"default:dirt_with_grass","default:dirt"}, 20, 0, 11000, 3, 31000)

-- ADDED Tenplus1 (Bucket of Milk gives 4 hearts and returns empty bucket)
minetest.register_craftitem("kpgmobs:bucket_milk", {
	description = "Bucket of Milk",
	inventory_image = "bucket_milk.png",
	on_use = minetest.item_eat(8, "bucket:bucket_empty"),
})

if minetest.setting_get("log_mods") then
	minetest.log("action", "kpgmobs loaded")
end