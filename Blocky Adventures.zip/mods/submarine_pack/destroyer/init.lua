local modpath = minetest.get_modpath("destroyer")

--api
dofile(modpath.."/api.lua")

--destroyers
dofile(modpath.."/destroyer.lua")