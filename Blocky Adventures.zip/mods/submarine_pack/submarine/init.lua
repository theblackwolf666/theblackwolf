local modpath = minetest.get_modpath("submarines")

--api
dofile(modpath.."/api.lua")

--submarines
dofile(modpath.."/submarine.lua")
