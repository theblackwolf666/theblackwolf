# Trample Path mod for Minetest

Make a trample path with your shovel. Rightclick on dirt, grass, gravel, sand or snow to make a path. Create a path automatically just by walking over the nodes. After a while you will see where you are walking very often.

You can add shovels from other mods just by adding them to the list of shovels

Don't forget to add your mod to depends.txt!

![screenshot](https://github.com/MarkuBu/trample_path/blob/master/screenshot.jpg)
