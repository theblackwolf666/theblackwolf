This mod adds letters to Minetest.

by BBmine


License:DWYWWPL
Do what you want with public license.