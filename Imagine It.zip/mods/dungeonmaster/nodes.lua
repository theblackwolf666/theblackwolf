-- mods/dungeonmaster/nodes.lua

minetest.register_node("dungeonmaster:brick", {
	description = "Dungeon Brick",
	tiles = {"dungeon_stone.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:floor", {
	description = "Dungeon Floor",
	tiles = {"dungeon_floor.png"},
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:hook", {
	description = "Dungeon Hook",
	tiles = {"dungeon_hook.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:moss", {
	description = "Dungeon Moss",
	tiles = {"dungeon_moss.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:drain", {
	description = "Dungeon Wall Drain",
	tiles = {"dungeon_wall_drain.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:drain2", {
	description = "Dungeon Floor Drain",
	tiles = {"dungeon_floor_drain.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:marks", {
	description = "Dungeon Marks",
	tiles = {"dungeon_marks.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:wet", {
	description = "Dungeon Wet Floor",
	tiles = {"dungeon_wet.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("dungeonmaster:bones", {
	description = "Dungeon Bones",
	tiles = {"dungeon_bones.png"},
	is_ground_content = false,
	groups = {cracky = 2, stone = 1},
	sounds = default.node_sound_stone_defaults(),
})