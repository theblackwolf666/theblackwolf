-- Bushes classic mod originally by unknown
-- now maintained by VanessaE
--
-- License:  WTFPL

local S = biome_lib.intllib

bushes_classic = {}

bushes_classic.bushes = {
    "strawberry",
	"blackberry",
	"blueberry",
	"raspberry",
	"gooseberry",
	"mixed_berry"
}

bushes_classic.bushes_descriptions = {
    "Strawberry",
	"Blackberry",
	"Blueberry",
	"Raspberry",
	"Gooseberry",
	"Mixed Berry"
}

bushes_classic.spawn_list = {}

local modpath = minetest.get_modpath('bushes_classic')
dofile(modpath..'/cooking.lua')
dofile(modpath..'/nodes.lua')

minetest.register_alias("bushes:basket_pies", "bushes:basket_strawberry")

print(S("[Bushes] Loaded."))
