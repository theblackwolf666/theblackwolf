-- main `S` code in init.lua
local S
S = farming.S

minetest.register_craftitem("farming_plus:orange_item", {
	description = S("Orange"),
      stack_max = 40,
	inventory_image = "farming_orange.png",
	on_use = minetest.item_eat(4),
})