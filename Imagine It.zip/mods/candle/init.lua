-- Candle from Wax and String/Cotton
minetest.register_node("candle:candle", {
	description = "Candle",
	drawtype = "plantlike",
	inventory_image = "candle_static.png",
	wield_image = "candle_static.png",
	tiles = {
		{
			name = "candle.png",
			animation={
				type="vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 1.0
			}
		},
	},	
	paramtype = "light",
	light_source = 11,
	sunlight_propagates = true,
	walkable = false,
	groups = {dig_immediate = 3, attached_node = 1},
	sounds = default.node_sound_defaults(),
	selection_box = {
		type = "fixed",
		fixed = { -0.15, -0.5, -0.15, 0.15, 0, 0.15 }
	},
})

doors.register("door_palm", {
		tiles = {{ name = "candle_door_wood.png", backface_culling = true }},
		description = "Palm Door",
		inventory_image = "candle_palmdoor.png",
		groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2},
})