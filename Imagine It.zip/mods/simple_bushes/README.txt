Simple_bushes is a fork from the flowers mod.
2015 by Glünggi WTFPL
((Plant_Pot-Texture from xdecor mod Creative Commons Attribution-ShareAlike 
4.0 International License))


Minetest 0.4 mod: flowers
=========================

License of source code:
-----------------------
Copyright (C) 2012-2013 Ironzorg, VanessaE

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

License of media (textures and sounds)
--------------------------------------
WTFPL
