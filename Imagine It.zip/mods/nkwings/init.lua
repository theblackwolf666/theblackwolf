-- Load files
dofile(minetest.get_modpath("nkwings").."/craftitems.lua")
