Braziers Mod for Minetest
============================

This is a mod for Minetest that adds fire braziers.

Licenses
--------------

- Code is liscenced CC0 (Except for fire code which is GNU Lesser General Public License 2.1 by Perttu Ahola (celeron55) <celeron55@gmail.com>)
- Textures are liscenced CC0 (Credit for the marble texture of the brazier textures goes to http://seamless-pixels.blogspot.de/)
- Nodebox by SB66 from Minetest Forums

Dependencies
--------------

- Fire

Forum Topic
--------------
For more info see: https://forum.minetest.net/viewtopic.php?f=9&t=9273
