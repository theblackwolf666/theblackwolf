modpath=minetest.get_modpath("brazier")

dofile(modpath.."/brazier.lua")
dofile(modpath.."/brazier_safe.lua")
