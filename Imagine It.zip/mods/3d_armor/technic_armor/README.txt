[mod] Technic Armor [technic_armor]
===================================

Adds tin, silver and technic materials to 3d_armor.
Requires technic (technic_worldgen at least) mod.

Depends: 3d_armor, technic_worldgen

Textures by poet.nohit and numberZero
