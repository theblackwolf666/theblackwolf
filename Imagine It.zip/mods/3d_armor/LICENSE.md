3D Armor - Visible Player Armor
===============================

License Source Code: Copyright (C) 2013-2017 Stuart Jones - LGPL v2.1

Armor Textures: Copyright (C) 2017 davidthecreator - CC-BY-SA 3.0

Special credit to Jordach and MirceaKitsune for providing the default 3d character model.

