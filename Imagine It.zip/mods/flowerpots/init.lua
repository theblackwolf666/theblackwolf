flowerpots = {plants = {}}

local creative = minetest.setting_getbool("creative_mode")

minetest.register_node("flowerpots:pot", {
	description = "Flower Pot",
	tiles = {"default_dirt.png", "flowerpots_pot.png"},
	paramtype = "light",
	drawtype = "mesh",
	mesh = "flowerpots_pot.obj",
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.1875, -0.5, -0.1875, 0.1875, -0.1875, 0.1875},
			{-0.1875, -0.3125, 0.1875, 0.25, -0.125, 0.25},
			{-0.25, -0.3125, -0.1875, -0.1875, -0.125, 0.25},
			{-0.25, -0.3125, -0.25, 0.1875, -0.125, -0.1875},
			{0.1875, -0.3125, -0.25, 0.25, -0.125, 0.1875}
		}
	},
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, -0.125, 0.25}
	},
	groups = {dig_immediate = 2},
	on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
		if not minetest.is_protected(pos, clicker:get_player_name()) then
			for k,v in pairs(flowerpots.plants) do
				if itemstack:get_name() == k then
					minetest.swap_node(pos, {name = v})
					if not creative then
						itemstack:take_item()
						return itemstack
					else
						return
					end
				end
			end
		end
	end
})

minetest.register_craft({
	output = "flowerpots:pot",
	recipe = {
		{"default:clay_brick", "", "default:clay_brick"},
		{"", "default:clay_brick", ""}
	}
})

function flowerpots.addplantlike(name, desc, plant, tile, box)
	minetest.register_node(":flowerpots:pot_"..name, {
		description = desc.." in a pot.",
		tiles = {tile, "default_dirt.png", "flowerpots_pot.png"},
		paramtype = "light",
		drawtype = "mesh",
		mesh = "flowerpots_pot_plantlike.obj",
		collision_box = {
			type = "fixed",
			fixed = {
				{-0.1875, -0.5, -0.1875, 0.1875, -0.1875, 0.1875},
				{-0.1875, -0.3125, 0.1875, 0.25, -0.125, 0.25},
				{-0.25, -0.3125, -0.1875, -0.1875, -0.125, 0.25},
				{-0.25, -0.3125, -0.25, 0.1875, -0.125, -0.1875},
				{0.1875, -0.3125, -0.25, 0.25, -0.125, 0.1875}
			}
		},
		selection_box = {
			type = "fixed",
			fixed = box
		},
		groups = {dig_immediate = 2, not_in_creative_inventory = 1},
		on_punch = function(pos, node, puncher, pointed_thing)
			if not minetest.is_protected(pos, puncher:get_player_name()) then
				minetest.swap_node(pos, {name = "flowerpots:pot"})
				local inv = puncher:get_inventory()
				if creative then
					if not inv:contains_item("main", plant) then
						inv:add_item("main", plant)
					end
				else
					inv:add_item("main", plant)
				end
			end
		end
	})

	flowerpots.plants[plant] = "flowerpots:pot_"..name
end

function flowerpots.addplantblock(name, desc, plant, tile_top, tile_side)
	minetest.register_node(":flowerpots:pot_"..name, {
		description = desc.." in a pot.",
		tiles = {tile_top, tile_side, "flowerpots_pot.png"},
		paramtype = "light",
		drawtype = "mesh",
		mesh = "flowerpots_pot_plantblock.obj",
		collision_box = {
			type = "fixed",
			fixed = {
				{-0.1875, -0.5, -0.1875, 0.1875, 0.5, 0.1875},
				{-0.25, -0.3125, -0.25, 0.25, -0.125, 0.25}
			}
		},
		selection_box = {
			type = "fixed",
			fixed = {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25}
		},
		groups = {dig_immediate = 2, not_in_creative_inventory = 1},
		on_punch = function(pos, node, puncher, pointed_thing)
			if not minetest.is_protected(pos, puncher:get_player_name()) then
				minetest.swap_node(pos, {name = "flowerpots:pot"})
				local inv = puncher:get_inventory()
				if creative then
					if not inv:contains_item("main", plant) then
						inv:add_item("main", plant)
					end
				else
					inv:add_item("main", plant)
				end
			end
		end
	})

	flowerpots.plants[plant] = "flowerpots:pot_"..name
end

flowerpots.addplantlike("sapling", "Sapling", "default:sapling", "default_sapling.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("junglesapling", "Jungle Sapling", "default:junglesapling", "default_junglesapling.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("pine_sapling", "Pine Sapling", "default:pine_sapling", "default_pine_sapling.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("acacia_sapling", "Acacia Tree Sapling", "default:acacia_sapling", "default_acacia_sapling.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("aspen_sapling", "Aspen Tree Sapling", "default:aspen_sapling", "default_aspen_sapling.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("dry_shrub", "Dry Shrub", "default:dry_shrub", "default_dry_shrub.png", {-0.25, -0.5, -0.25, 0.25, 0, 0.25})
flowerpots.addplantlike("rose", "Rose", "flowers:rose", "flowers_rose.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("tulip", "Tulip", "flowers:tulip", "flowers_tulip.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("dandelion_yellow", "Yellow Dandelion", "flowers:dandelion_yellow", "flowers_dandelion_yellow.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("geranium", "Blue Geranium", "flowers:geranium", "flowers_geranium.png", {-0.25, -0.5, -0.25, 0.25, 0.5, 0.25})
flowerpots.addplantlike("viola", "Viola", "flowers:viola", "flowers_viola.png", {-0.25, -0.5, -0.25, 0.25, 0.1125, 0.25})
flowerpots.addplantlike("dandelion_white", "White Dandelion", "flowers:dandelion_white", "flowers_dandelion_white.png", {-0.25, -0.5, -0.25, 0.25, 0.1125, 0.25})
flowerpots.addplantlike("mushroom_red", "Red Mushroom", "flowers:mushroom_red", "flowers_mushroom_red.png", {-0.25, -0.5, -0.25, 0.25, 0.3125, 0.25})
flowerpots.addplantlike("mushroom_brown", "Brown Mushroom", "flowers:mushroom_brown", "flowers_mushroom_brown.png", {-0.25, -0.5, -0.25, 0.25, 0.3125, 0.25})

flowerpots.addplantblock("cactus", "Cactus", "default:cactus", "default_cactus_top.png", "default_cactus_side.png")
