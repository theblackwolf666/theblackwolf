local path = minetest.get_modpath("nsspf")

dofile(path.."/spawn.lua")
dofile(path.."/mushrooms.lua")