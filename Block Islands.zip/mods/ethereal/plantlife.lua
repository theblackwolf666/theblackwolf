
--= Define Fern & Shrubs

--= Define Moss Types (Has grass textures on all sides)

function ethereal.add_moss(typ, descr, texture, receipe_item)
	minetest.register_node('ethereal:'..typ..'_moss', {
		description = descr..' Moss',
		tiles = { texture },
		is_ground_content = true,
		groups = {crumbly=3 },
		sounds = default.node_sound_dirt_defaults
	})

	minetest.register_craft({
		output = 'ethereal:'..typ..'_moss',
		recipe = {{'default:dirt', receipe_item }} 
	});
end

ethereal.add_moss( 'fiery',    'Fiery',    'ethereal_fiery_grass.png',  'ethereal:dry_shrub' ); 
ethereal.add_moss( 'gray',     'Gray',     'ethereal_gray_grass.png',   'ethereal:snowygrass' );

--= Saplings and Leaves Can Be Used as Fuel

--= Define Food Items

-- Coconut (Gives 4 coconut slices, each heal 1/2 heart)
minetest.register_node("ethereal:coconut", {
	drawtype = "plantlike",
	walkable = false,
	paramtype = "light",
      stack_max = 40,
	description = "Coconut",
	tiles = {"moretrees_coconut.png"},
	is_ground_content = true,
	groups = {cracky=2,snappy=2,choppy=2,flammable=1,leafdecay=3,leafdecay_drop=1},
	drop = 'ethereal:coconut_slice 4',
	sounds = default.node_sound_wood_defaults(),
})

-- Coconut Slice (Heals half heart when eaten)
minetest.register_craftitem("ethereal:coconut_slice", {
	description = "Coconut Slice",
      stack_max = 40,
	inventory_image = "moretrees_coconut_slice.png",
	on_use = minetest.item_eat(1),
})

-- Crystal Shrub (not Flammable - too cold to burn)
minetest.register_node("ethereal:crystalgrass", {
        description = "Crystal Grass",
        drawtype = "plantlike",
        visual_scale = 0.9,
        tiles = {"ethereal_crystalgrass.png"},
        inventory_image = "ethereal_crystalgrass.png",
        wield_image = "ethereal_crystalgrass.png",
        paramtype = "light",
	waving = 1,
        walkable = false,
        buildable_to = true,
        is_ground_content = true,
        groups = {snappy=3,flora=1,attached_node=1},
        sounds = default.node_sound_leaves_defaults(),
        selection_box = {
                type = "fixed",
                fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
        },
})

-- Wild Onion
minetest.register_craftitem("ethereal:wild_onion_plant", {
	description = "Wild Onion",
	inventory_image = "wild_onion.png",
	wield_image = "wild_onion.png",
      stack_max = 40,
	sounds = default.node_sound_defaults(),
})

--= Additional Crafting Recipes

-- Gravel (5x cobble in X pattern gives 10 gravel)
minetest.register_craft({
	output = 'default:gravel 10',
	recipe = {
		{'default:cobble', '', 'default:cobble'},
		{'', 'default:cobble', ''},
		{'default:cobble', '', 'default:cobble'},
	}
})