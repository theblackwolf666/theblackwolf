
-- Function to Register Saplings

ethereal.register_sapling = function( sapling_node_name, sapling_descr, sapling_texture )

	-- if the sapling does not exist yet, create a node for it
	if( not( minetest.registered_nodes[ sapling_node_name ] )) then
		minetest.register_node( sapling_node_name, {
			description = sapling_descr,
			drawtype = "plantlike",
			visual_scale = 1.0,
			tiles = { sapling_texture},
                  stack_max = 40,
			inventory_image = sapling_texture,
			wield_image = sapling_texture,
			paramtype = "light",
			walkable = false,
			groups = {snappy=2,dig_immediate=3,flammable=2,ethereal_sapling=1},
			sounds = default.node_sound_defaults(),
		})
	end
end

-- Register Saplings

ethereal.register_sapling( 'ethereal:banana_tree_sapling', 'Banana Tree Sapling', 'banana_tree_sapling.png' );
ethereal.register_sapling( 'ethereal:palm_sapling', 'Palm Sapling', 'moretrees_palm_sapling.png' );

-- Find centre position for Tree to grow

ethereal.centre_place = function(pos, center_offset, schematic_size, schem_name)

	-- Calculate Tree's centre position (to grow where sapling was)
	-- an offset depending on rotation; rotation thus can't be "random"

	local rotation = tostring( (math.random( 4 )-1) * 90);
	local p = {x=pos.x, y=pos.y, z=pos.z};
	if(     rotation=="0" ) then
		p.x = pos.x - center_offset.x;
		p.z = pos.z - center_offset.z;
	elseif( rotation=="90" ) then
		p.x = pos.x - center_offset.z;
		p.z = pos.z - ( schematic_size.x - center_offset.x - 1);
	elseif( rotation=="180" ) then
		p.x = pos.x - ( schematic_size.x - center_offset.x - 1);
		p.z = pos.z - ( schematic_size.z - center_offset.z - 1);
	elseif( rotation=="270" ) then
		p.x = pos.x - ( schematic_size.z - center_offset.z - 1);
		p.z = pos.z - center_offset.x;
	end

	-- Remove Sapling and Place Tree Schematic

	minetest.env:set_node(pos, {name="air"}) -- quicker than remove_node

	minetest.place_schematic(p, minetest.get_modpath("ethereal").."/schematics/"..schem_name..".mts", rotation, {}, false );

end

-- Grow saplings

minetest.register_abm({
	nodenames = { "group:ethereal_sapling" },
	interval = 20,
	chance = 25,
	action = function(pos, node)

		local node_under =  minetest.get_node({x=pos.x, y=pos.y-1, z=pos.z}).name;

		-- Check if Sapling is growing on correct substrate

		if (node.name == "ethereal:banana_tree_sapling" and node_under == "ethereal:grove_dirt") then
			ethereal.centre_place ( pos, {x=2,y=0,z=2}, {x=7,y=8,z=7}, "bananatree"); return
		elseif (node.name == "ethereal:palm_sapling" and node_under == "default:sand") then
			ethereal.centre_place ( pos, {x=3,y=0,z=4}, {x=7,y=10,z=7}, "palmtree"); return
		end

	end,
})