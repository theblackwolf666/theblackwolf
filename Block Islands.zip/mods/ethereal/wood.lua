
--= Define Tree and Mushroom Trunks

-- Scorched Tree Trunk
minetest.register_node("ethereal:scorched_tree", {
	description = "Scorched Tree",
	tiles = {"scorched_tree_top.png", "scorched_tree_top.png", "scorched_tree.png"},
	groups = {tree=1,choppy=2,oddly_breakable_by_hand=1,put_out_fire=1},
	sounds = default.node_sound_wood_defaults(),
      stack_max = 40,
	paramtype2 = "facedir",
})

-- Palm Tree Trunk
minetest.register_node("ethereal:palm_trunk", {
	description = "Palm Trunk",
	tiles = {"moretrees_palm_trunk_top.png", "moretrees_palm_trunk_top.png", "moretrees_palm_trunk.png"},
	groups = {tree=1,choppy=2,oddly_breakable_by_hand=1,flammable=2},
	sounds = default.node_sound_wood_defaults(),
      stack_max = 40,
	paramtype2 = "facedir",
})

-- Banana Tree Trunk
minetest.register_node("ethereal:banana_trunk", {
	description = "Banana Trunk",
	tiles = {"banana_trunk_top.png", "banana_trunk_top.png", "banana_trunk.png"},
	groups = {tree=1,choppy=2,oddly_breakable_by_hand=1,flammable=2},
	sounds = default.node_sound_wood_defaults(),
      stack_max = 40,
	paramtype2 = "facedir",
})

--= Define Tree Wood

-- Palm Tree Wood
minetest.register_node("ethereal:palm_wood", {
	description = "Palm Wood",
	tiles = {"moretrees_palm_wood.png"},
	is_ground_content = true,
      stack_max = 40,
	groups = {wood=1,choppy=2,oddly_breakable_by_hand=1,flammable=3},
	sounds = default.node_sound_wood_defaults(),
})

-- Banana Tree Wood
minetest.register_node("ethereal:banana_wood", {
	description = "Banana Wood",
	tiles = {"banana_wood.png"},
	is_ground_content = true,
      stack_max = 40,
	groups = {wood=1,choppy=2,oddly_breakable_by_hand=1,flammable=3},
	sounds = default.node_sound_wood_defaults(),
})

-- Turn Palm Tree Trunk into Wood
minetest.register_craft({
	output = 'ethereal:palm_wood 4',
	type = shapeless,
	recipe = {
		{'ethereal:palm_trunk', ''},
		{'', ''},
		{'', ''},
	}
})

-- Turn Banana Tree Trunk into Wood
minetest.register_craft({
	output = 'ethereal:banana_wood 4',
	type = shapeless,
	recipe = {
		{'ethereal:banana_trunk', ''},
		{'', ''},
		{'', ''},
	}
})

--= NOTE: Minetest 0.4.9 turns any registered wood into sticks, no recipe needed