ethereal = {}

--= Define Biomes

minetest.register_biome({
	name           = "caves",
	node_top       = "default:desert_stone",
	depth_top      = 2,
	node_filler    = "air",
	depth_filler   = 8,
	height_min     = 4,
	height_max     = 41,
	heat_point     = 15.0,
	humidity_point = 25.0,
})

minetest.register_biome({
	name           = "fiery",
	node_top       = "ethereal:fiery_dirt_top",
	depth_top      = 1,
	node_filler    = "default:dirt",
	depth_filler   = 7,
	height_min     = 5,
	height_max     = 65,
	heat_point     = 60.0,
	humidity_point = 20.0,
})

minetest.register_biome({
	name           = "fiery2",
	node_top       = "ethereal:fiery_dirt_top",
	depth_top      = 1,
	node_filler    = "default:dirt",
	depth_filler   = 7,
	height_min     = 5,
	height_max     = 65,
	heat_point     = 80.0,
	humidity_point = 10.0,
})

--= Register Biome Decoration (Schematics)

local path = minetest.get_modpath("ethereal")

-- Large Lava Crater
minetest.register_decoration({
	deco_type = "schematic",
	place_on = "ethereal:fiery_dirt_top",
	sidelen = 16,
	fill_ratio = 0.010,
	biomes = {"fiery2"},
	schematic = path.."/schematics/volcanol.mts",
	flags = "place_center_x, place_center_z",
--	replacements = {{"default:stone", "default:desert_stone"}},
})

-- Old Rail Section in Desert
minetest.register_decoration({
	deco_type = "schematic",
	place_on = "default:sandstone",
	sidelen = 16,
	fill_ratio = 0.002,
	biomes = {"desertsandstone"},
	schematic = path.."/schematics/rail.mts",
	flags = "place_center_x, place_center_z",
})

-- Different Old Rail Section in Desert
minetest.register_decoration({
	deco_type = "schematic",
	place_on = "default:sandstone",
	sidelen = 16,
	fill_ratio = 0.002,
	biomes = {"desertsandstone"},
	schematic = path.."/schematics/railtwo.mts",
	flags = "place_center_x, place_center_z",
})

--= Smaller Plant Decoration

-- Crystal Spikes & Grass
minetest.register_decoration({
	deco_type = "simple",
      place_on = {"default:ice_stone", "default:silver_sand"},
	sidelen = 16,
	fill_ratio = 0.02,
      biomes = {"icesheet", "cold_desert", "tundra"},
	decoration = {"ethereal:crystal_spike", "ethereal:crystalgrass"},
})

-- Wild Onions
minetest.register_decoration({
	deco_type = "simple",
	place_on = {"default:dirt_with_grass"},
	sidelen = 2,
	fill_ratio = 0.02,
	biomes = {"grassy", "grassytwo", "prairie"},
	decoration = "ethereal:wild_onion_4",
})

--= Specific Plant Placements

-- Palm Tree on Sand next to Water
minetest.register_on_generated(function(minp, maxp, seed)
	if maxp.y >= 2 and minp.y <= 0 then
		local perlin1 = minetest.get_perlin(354, 3, 0.7, 100)
		-- Assume X and Z lengths are equal
		local divlen = 8
		local divs = (maxp.x-minp.x)/divlen+1;
		for divx=0,divs-1 do
		for divz=0,divs-1 do
			local x0 = minp.x + math.floor((divx+0)*divlen)
			local z0 = minp.z + math.floor((divz+0)*divlen)
			local x1 = minp.x + math.floor((divx+1)*divlen)
			local z1 = minp.z + math.floor((divz+1)*divlen)

			-- Find random positions for palm based on this random
			local pr = PseudoRandom(seed+1)
				local x = pr:next(x0, x1)
				local z = pr:next(z0, z1)
				if minetest.get_node({x=x,y=1,z=z}).name == "default:sand" and
					minetest.find_node_near({x=x,y=1,z=z}, 1, "default:water_source") then
					schematic = path.."/schematics/palmtree.mts"
					minetest.place_schematic({x=x-3,y=2,z=z-4}, schematic, 0, '', 0)
				end
			end
		end
	end
end)