--= Register Crystal Items

-- Crystal Spike (Hurts if you touch it - thanks to ZonerDarkRevention for his DokuCraft DeviantArt crystal texture)
minetest.register_node("ethereal:crystal_spike", {
	description = "Crystal Spike",
	drawtype = "plantlike",
	tiles = { "crystal_spike.png" },
	inventory_image = "crystal_spike.png",
	wield_image = "crystal_spike.png",
	paramtype = "light",
	light_source = LIGHT_MAX - 7,
	walkable = false,
	damage_per_second = 1,
	groups = {cracky=1,falling_node=1},
	sounds = default.node_sound_glass_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})

-- Crystal Ingot and Recipe
minetest.register_craftitem("ethereal:crystal_ingot", {
	description = "Crystal Ingot",
	inventory_image = "crystal_ingot.png",
})

-- Crystal Gilly Staff and Recipe (When used it replenishes your air supply while underwater)

minetest.register_tool("ethereal:crystal_gilly_staff", {
	description = "Crystal Gilly Staff",
	inventory_image = "crystal_gilly_staff.png",
	wield_image = "crystal_gilly_staff.png",

	on_use = function(itemstack, user, pointed_thing)

		if user:get_breath() < 10 then
			user:set_breath(10)
		end

	end,
})

minetest.register_craft({
	output = 'ethereal:crystal_gilly_staff',
	recipe = {
		{'', '', 'ethereal:crystal_spike'},
		{'', 'ethereal:crystal_spike', ''},
		{'default:stick', '', ''},
	}
})