-- Change j to 1 for 3D style leaves, otherwise 0 is 2D

local j = 1

if j == 0 then
	leaftype = "plantlike"
else
	leaftype = "allfaces_optional"
end

--= Define leaves for ALL trees (and Mushroom Tops)

-- Default Banana Tree Leaves
minetest.register_node("ethereal:bananaleaves", {
	description = "Banana Leaves",
	drawtype = leaftype,
	visual_scale = 1.1,
	tiles = {"banana_leaf.png"},
	inventory_image = "banana_leaf.png",
	paramtype = "light",
	waving = 1,
      stack_max = 40,
	groups = {snappy=3, leafdecay=3, leaves=1},
	drop = {
		max_items = 1,
		items = {
			{	items = {'ethereal:banana_tree_sapling'},
				rarity = 20,
			},
			{	items = {'ethereal:bananaleaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),
})

-- Palm Tree Leaves
minetest.register_node("ethereal:palmleaves", {
	description = "Palm Leaves",
	drawtype = leaftype,
	visual_scale = 1.1,
	tiles = {"moretrees_palm_leaves.png"},
	inventory_image = "moretrees_palm_leaves.png",
	paramtype = "light",
	waving = 1,
      stack_max = 40,
	groups = {snappy=3, leafdecay=3, leaves=1},
	drop = {
		max_items = 1,
		items = {
			{	items = {'ethereal:palm_sapling'},
				rarity = 20,
			},
			{	items = {'ethereal:palmleaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),
})