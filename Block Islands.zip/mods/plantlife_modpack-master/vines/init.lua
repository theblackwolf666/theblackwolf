vines = {
  name = 'vines',
  recipes = {}
}

dofile( minetest.get_modpath( vines.name ) .. "/functions.lua" )
dofile( minetest.get_modpath( vines.name ) .. "/aliases.lua" )
dofile( minetest.get_modpath( vines.name ) .. "/vines.lua" )

print("[Vines] Loaded!")
