License of Textures: WTFPL

crafting.table_front.png
crafting.table_side.png
crafting.table_top.png

------------------------------------
copyright (c) 2013-2014 by BlockMen

License for:
crafting_guide_contents.png
crafting_guide_cover.png

CC0 public domain by FaceDeer