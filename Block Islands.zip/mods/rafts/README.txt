This mod is part of Minetest TNG
================================

License of source code:
-----------------------
Copyright (c) 2012 PilzAdam
Copyright (c) 2014 BlockMen
Copyright (c) 2014 paramat

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


License of media (textures, sounds, meshes):
--------------------------------------------
(by Authors)

Zeg9 (WTFPL):
  boat_*.png

sofar (WTFPL):
  boats_boat.obj


Details of Licenses:
--------------------

WTFPL:
  Do What the Fuck You Want to Public License
  http://www.wtfpl.net/txt/copying/
