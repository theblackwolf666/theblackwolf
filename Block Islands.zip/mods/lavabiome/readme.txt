This is dependant on the default mod of this subgame for it to be a biome,
without it, this mod simply adds burnt dirt and lava geysers.