﻿mind controller, control aliveai bots


Controls:
sneak = exit

w/up = walk
s/down = run
s/down + JUMP = JUMPx2
jump = jump

hold use/leftclick = use bot tool (if it have one)
hold use/leftclick controller on block = bot dig
place/rightclick with controller on block = place selected block (or jump and place controler to sellect again)

punch controller = bot punch
punch controller on item = bot picks up

D/right & S/left = toggle bot self control

mobs redo:
punch with controller on an object, to set the mobs in a attacking mod, punch in air to stop it.