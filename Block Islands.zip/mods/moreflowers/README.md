# moreflowers
by sys4

A Minetest mod that add more flowers

This simple mod extend the flowers mod from MT_Game by adding more flowers.

Dependence:
- flowers

Optional Dependencies:
- farming
- vessels
- bonemeal by TenPlus1 (https://forum.minetest.net/viewtopic.php?f=9&t=16446)

For now this mod add:
- Wild carrot: spawn into biomes grassland, deciduous_forest and coniferous_forest.
- Teosinte (corn ancestor): spawn into biome rainforest.
  
- Bunch of flowers:
  If farming mod is loaded then you can craft a bunch of flowers with any items from the flower group and a string of cotton.
  
- Bunch into a vase:
  If farming and vessels mods are loaded then you can craft a bunch into a vase which you can place anywhere.

LICENCES:
- Code & Textures: GPLv3
