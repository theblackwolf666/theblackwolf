-- AWARDS
--
-- Copyright (C) 2013-2015 rubenwardy
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU Lesser General Public License as published by
-- the Free Software Foundation; either version 2.1 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU Lesser General Public License for more details.
-- You should have received a copy of the GNU Lesser General Public License along
-- with this program; if not, write to the Free Software Foundation, Inc.,
-- 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
--


local S
if (intllib) then
	dofile(minetest.get_modpath("intllib").."/intllib.lua")
	S = intllib.Getter(minetest.get_current_modname())
else
	S = function ( s ) return s end
end

dofile(minetest.get_modpath("awards").."/api.lua")
dofile(minetest.get_modpath("awards").."/chat_commands.lua")
dofile(minetest.get_modpath("awards").."/sfinv.lua")
dofile(minetest.get_modpath("awards").."/unified_inventory.lua")
dofile(minetest.get_modpath("awards").."/triggers.lua")
awards.set_intllib(S)

	-- Light it up
	awards.register_achievement("award_lightitup",{
		title = S("I Can Finally See"),
		description = S("Place 1 Torch."),
		icon = "default_torchy.png",
		trigger = {
			type = "place",
			node = "default:torch",
			target = 1
		}
	})

	-- Light ALL the things!
	awards.register_achievement("award_well_lit",{
		title = S("Bright Up In Here"),
		description = S("Place 100 Torches."),
		icon = "default_torchy.png",
		trigger = {
			type = "place",
			node = "default:torch",
			target = 100
		}
	})

	-- Lumberjack
	awards.register_achievement("award_lumberjack", {
	title = S("Lumberjack"),
		description = S("Enter A Forest And Chop 100 Trees."),
		icon = "awards_update.png",
		trigger = {
			type = "dig",
			node = "default:tree",
			target = 100
		}
	})

	-- Found a Nyan cat!
	awards.register_achievement("award_nyanfind", {
		title = S("Found A Nyan cat"),
		description = S("Collect a Nyan cat's rainbow."),
		icon = "awards_update.png",
		trigger = {
			type = "dig",
			node = "default:nyancat_rainbow",
			target = 1
		}
	})

	-- The Miner
	awards.register_achievement("award_mine2", {
		title = S("The Miner"),
		description = S("Dig 100 stone blocks."),
		icon = "awards_update.png",
		trigger = {
			type = "dig",
			node = "default:stone",
			target = 100		}
	})

	awards.register_achievement("awards_crafter_of_sticks", {
		title = S("The Stick Collector"),
		description = S("Craft 100 sticks."),
		icon = "awards_update.png",
		trigger = {
			type = "craft",
			item = "default:stick",
			target = 100
		}
	})

	-- Proof that player visited snowy lands
	awards.register_achievement("awards_snowblock", {
		title = S("Very Simple Snow Man"),
		description = S("Place three snow blocks."),
		icon = "awards_update.png",
		trigger = {
			type = "place",
			node = "default:snowblock",
			target = 3
		}
	})

	awards.register_achievement("awards_gold_ore", {
		title = S("It's Gold"),
		description = S("Mine your first gold ore."),
		icon = "awards_update.png",
		trigger = {
			type = "dig",
			node = "default:stone_with_gold",
			target = 1
		}
	})

	awards.register_achievement("awards_gold_rush", {
		title = S("Gold Rush"),
		description = S("Mine 50 gold ores."),
		icon = "awards_update.png",
		trigger = {
			type = "dig",
			node = "default:stone_with_gold",
			target = 50
		}
	})

	awards.register_achievement("award_furnace", {
		title = S("The Furnace"),
		description = S("Craft 1 Furnace."),
		icon = "awards_update.png",
		trigger = {
			type = "craft",
			item= "default:furnace",
			target = 1
		}
	})

awards.register_achievement("award_backpack", {
		title = S("Pack It Up"),
		description = S("Craft a backpack."),
		icon = "awards_update.png",
		trigger = {
			type = "craft",
			item= "backpacks:backpack",
			target = 1
		}
	})

if minetest.get_modpath("wool") and minetest.get_modpath("farming") then
	awards.register_achievement("awards_wool", {
		title = S("Out Camping"),
		description = S("Craft a sleeping bag."),
		icon = "awards_update.png",
		trigger = {
			type = "craft",
			item = "default_mat.png",
			target = 1
		}
	})
end

if minetest.get_modpath("default") then
	-- Digging Lots
	awards.register_achievement("award_dirt2",{
		title = S("Dirt Collector"),
		description = S("Collect 50 Grass blocks."),
		icon = "awards_update.png",
		trigger = {
			type = "dig",
			node = "default:dirt_with_grass",
			target = 50
		}
	})
end

-- Copper
	awards.register_achievement("award_copper", {
	title = S("Found Copper"),
		description = S("Mine Copper."),
            icon = "awards_update.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_copper",
			target = 1
		}
	})

-- Coal
	awards.register_achievement("award_coal", {
	title = S("Discoverd Coal"),
		description = S("Mine Coal."),
            icon = "awards_update.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_coal",
			target = 1
		}
	})

-- Camper
	awards.register_achievement("award_camper", {
	title = S("Warmer Nights"),
		description = S("Make A Campfire."),
            icon = "awards_update.png",
      		trigger = {
			type = "craft",
			item = "campfire:campfire",
			target = 1
		}
	})

-- Coal2
	awards.register_achievement("award_coal2", {
	title = S("Smutty Hands"),
		description = S("Mine 35 Pieces Of Coal."),
            icon = "awards_update.png",
      		trigger = {
			type = "dig",
			node = "default:stone_with_coal",
			target = 35
		}
	})

-- Posted
	awards.register_achievement("award_posted", {
	title = S("Posted!"),
		description = S("Craft A Wooden Sign!"),
            icon = "awards_update.png",
      		trigger = {
			type = "craft",
			item = "default:sign_wall_wood",
			target = 1
		}
	})

-- Bucket
	awards.register_achievement("award_bucket", {
	title = S("Scoop It Up"),
		description = S("Craft A Bucket To Gather Liquids!"),
            icon = "awards_update.png",
      		trigger = {
			type = "craft",
			item = "bucket:bucket_empty",
			target = 1
		}
	})

-- Putaway
	awards.register_achievement("award_putaway", {
	title = S("Trash It"),
		description = S("Create A Trashcan"),
            icon = "awards_update.png",
      		trigger = {
			type = "craft",
			item = "trash_can:trash_can_wooden",
			target = 1
		}
	})

-- Diver
	awards.register_achievement("award_diver", {
	title = S("The Diver"),
		description = S("Craft A Scuba Helmet To Explore The Seas Safely"),
            icon = "awards_update.png",
      		trigger = {
			type = "craft",
			item = "scuba:scuba_helmet",
			target = 1
		}
	})
