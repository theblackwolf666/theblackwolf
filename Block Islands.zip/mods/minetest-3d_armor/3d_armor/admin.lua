minetest.register_alias("adminboots","3d_armor:boots_admin")
minetest.register_alias("adminhelmet","3d_armor:helmet_admin")
minetest.register_alias("adminchestplate","3d_armor:chestplate_admin")
minetest.register_alias("adminlegginss","3d_armor:leggings_admin")

minetest.register_tool("3d_armor:helmet_admin", {
	description = "Ruby Helmet",
	inventory_image = "3d_armor_inv_helmet_admin.png",
	groups = {armor_head=10, armor_heal=0, armor_use=1000, armor_water=1},
	wear = 0,
	on_drop = function(itemstack, dropper, pos)
		return
	end,
})

minetest.register_tool("3d_armor:chestplate_admin", {
	description = "Ruby Chestplate",
	inventory_image = "3d_armor_inv_chestplate_admin.png",
	groups = {armor_torso=10, armor_heal=0, armor_use=1000},
	wear = 0,
	on_drop = function(itemstack, dropper, pos)
		return
	end,
})

minetest.register_tool("3d_armor:leggings_admin", {
	description = "Ruby Leggings",
	inventory_image = "3d_armor_inv_leggings_admin.png",
	groups = {armor_legs=10, armor_heal=0, armor_use=1000},
	wear = 0,
	on_drop = function(itemstack, dropper, pos)
		return
	end,
})

minetest.register_tool("3d_armor:boots_admin", {
	description = "Ruby Boots",
	inventory_image = "3d_armor_inv_boots_admin.png",
	groups = {armor_feet=10, armor_heal=0, armor_use=2000},
	wear = 0,
	on_drop = function(itemstack, dropper, pos)
		return
	end,
})

