-- NODES

-- ENTITIES

-- The registration of the entities' code is copied from celeron55's mob (the DM's fireball)

minetest.register_entity("clams:whiteshell", {
	description="Clam",
	hp_max = 15,
      stack_max = 40,
	physical = true,
	collisionbox = {-0.2,-0.2,-0.2, 0.2,0.2,0.2},
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"clams_whiteshell.png^[makealpha:128,128,0"},
	spritediv = {x=1, y=3},
	initial_sprite_basepos = {x=0, y=0},
	drops = {
		{name = "clams:crushedwhite", chance = 1, min = 1, max = 4},
	},

	phase = 0,
	phasetimer = 0,

	on_activate = function(self, staticdata)
		minetest.log("whiteshell activated!")
	end,

	on_step = function(self, dtime)
		self.phasetimer = self.phasetimer + dtime
		if self.phasetimer > 2.0 then
			self.phasetimer = self.phasetimer - 2.0
			self.phase = self.phase + 1
			if self.phase >= 3 then
				self.phase = 0
			end
			self.object:setsprite({x=0, y=self.phase})
			phasearmor = {
				[0]={fleshy=0},
				[1]={fleshy=30},
				[2]={fleshy=70}
			}
			self.object:set_armor_groups(phasearmor[self.phase])
		end
	end,

	on_punch = function(self, hitter)
			if self.object:get_hp() <= 0 then
				if hitter and hitter:is_player() and hitter:get_inventory() then
					for _,drop in ipairs(self.drops) do
						if math.random(1, drop.chance) == 1 then
							hitter:get_inventory():add_item("main", ItemStack(drop.name.." "..math.random(drop.min, drop.max)))
						end
					end
				else
					for _,drop in ipairs(self.drops) do
						if math.random(1, drop.chance) == 1 then
							for i=1,math.random(drop.min, drop.max) do
								local obj = minetest.add_item(self.object:getpos(), drop.name)
								if obj then
									obj:get_luaentity().collect = true
									local x = math.random(1, 5)
									if math.random(1,2) == 1 then
										x = -x
									end
									local z = math.random(1, 5)
									if math.random(1,2) == 1 then
										z = -z
									end
									obj:setvelocity({x=1/x, y=obj:getvelocity().y, z=1/z})
								end
							end
						end
					end
				end
			end
		end,
})

-- CRAFT ITEMS

minetest.register_craftitem("clams:crushedwhite", {
	description = "Clam",
      stack_max = 40,
	inventory_image = "clams_crushedwhite.png",
})

minetest.register_craftitem("clams:cookedclam", {
	description = "Cooked Clam",
      stack_max = 40,
	inventory_image = "clams_cookedclam.png",
      on_use = minetest.item_eat(3),
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_craft({
	type = "cooking",
	output = "clams:cookedclam",
	recipe = "clams:crushedwhite",
})

-- ALIASES

minetest.register_alias("clams:yellowshell","clams:whiteshell")
minetest.register_alias("clams:redshell","clams:whiteshell")
minetest.register_alias("clams:blueshell","clams:whiteshell")

minetest.register_alias("clams:crushedyellow","clams:crushedwhite")
minetest.register_alias("clams:crushedred","clams:crushedwhite")
minetest.register_alias("clams:crushedblue","clams:crushedwhite")
minetest.register_alias("clams:crushedblack","clams:crushedwhite")

if( minetest.get_modpath( "colormachine") ~= nil ) then
	minetest.register_alias("clams:emptybleacher","colormachine:colormachine")
	minetest.register_alias("clams:filledbleacher","colormachine:colormachine")
	minetest.register_alias("clams:readybleacher","colormachine:colormachine") else
		minetest.register_alias("clams:emptybleacher","default:mese")
		minetest.register_alias("clams:filledbleacher","default:mese")
		minetest.register_alias("clams:readybleacher","default:mese")
	return
end