RandomMessages mod by arsdragonfly.
Put your messages in (world directory)/random_messages,1 message per line.
Messages can be all kinds of hints, mod usage, etc.
Add/Remove messages on the fly:
/rmessages viewmessages
to see all the messages.
/rmessages addmessage blah blah blah
to add the random message blah blah blah.
/rmessages removemessage 2
to remove the 2nd random message in /rmessages viewmessages .
In minetest.conf, random_messages_interval decides how often a message is sent.
Released under CC0.
Special thanks to:
Michael Rasmussen (michael@jamhome.us)
Enjoy it! ^_^
arsdragonfly@gmail.com
6/19/2013
