--[[
RandomMessages mod by arsdragonfly.
arsdragonfly@gmail.com
6/19/2013
--]]
--Time between two subsequent messages.
local MESSAGE_INTERVAL = 0

math.randomseed(os.time())

random_messages = {}
random_messages.messages = {} --This table contains all messages.

function table.count( t )
	local i = 0
	for k in pairs( t ) do i = i + 1 end
	return i
end

function table.random( t )
	local rk = math.random( 1, table.count( t ) )
	local i = 1
	for k, v in pairs( t ) do
		if ( i == rk ) then return v, k end
		i = i + 1
	end
end

function random_messages.initialize() --Set the interval in minetest.conf.
	minetest.setting_set("random_messages_interval",100)
	minetest.setting_save();
	return 100
end

function random_messages.set_interval() --Read the interval from minetest.conf(set it if it doesn'st exist)
	MESSAGE_INTERVAL = tonumber(minetest.setting_get("random_messages_interval")) or random_messages.initialize()
end

function random_messages.check_params(name,func,params)
	local stat,msg = func(params)
	if not stat then
		minetest.chat_send_player(name,msg)
		return false
	end
	return true
end

function random_messages.read_messages()
	local line_number = 1
	local input = io.open(minetest.get_worldpath().."/random_messages","r")
	if not input then
		local output = io.open(minetest.get_worldpath().."/random_messages","w")
            output:write("I read that this here guide book can help me create things from the wilderness...\n")
            output:write("It sure is boring around here...\n")
            output:write("I'm getting too old for this adventuring stuff...\n")
            output:write("*cough,cough,cough* My throat is sore...\n")
            output:write("*sigh* What a day....\n")
            output:write("I sure am feeling sleepy...\n")
            output:write("I'd like to eat some steak right now...\n")
            output:write("Why do I gotta be so alone?\n")
            output:write("Just me and my shadow here all alone...\n")
            output:write("I wonder what I'll write in my journal today?\n")
            output:write("*starts humming*........\n")
            output:write("*FART* ... Ahh,that's better,*cough,cough*\n")
            output:write("Sure could use a nice warm bed....\n")
            output:write("A salad would be nice right about now...\n")
            output:write("My feet hurt,I've been traveling forever....\n")
            output:write("My back hurts...ow,ow....\n")
            output:write("I wonder what time it is?\n")
            output:write("I reckon I shouldn't have took that survival bet...\n")
            output:write("*Yawn* How much longer before our next meal?\n")
            output:write("ACHOOOO! Darn sinuses....\n")
            output:write("Now I know how Wem felt......\n")
            output:write("I wish I had a box of crackers...\n")
            output:write("Hmm,I wonder which way is North and South from here?\n")
            output:write("Today is the day I do something!\n")
            output:write("Sure hope I don't fall into a deep hole.\n")
            output:write("I'd love to have a cheese burger...\n")
            output:write("I don't care much about these onions...\n")
            output:write("The only thing in life I hate is my old shoes.\n")
            output:write("I should have packed a flashlight and a can of Red Beans....\n")
            output:write("Ouch! I twisted my ankle...\n")
            output:write("I'd love a hotdog right now...\n")
            output:write("I wonder what Sam and Steve are up to these days?\n")
            output:write("My dumb son John couldn't handle surviving without his WiFi...\n")
            output:write("I miss my sofa back at home...\n")
            output:write("I can't wait to eat and then go back to sleep.\n")
            output:write("I hate when I have to swim,I'm too old to lift my legs that high....\n")
            output:write("*Cough,cough* Hmm...Am I lost?\n")
            output:write("Today isn't my day...\n")
            output:write("My retirement funds don't get mailed here...\n")
            output:write("I can't even enjoy Bingo night anymore...\n")
            output:write("I sure wish I would have remembered to pack my mints....\n")
            output:write("I miss my flat screen HD television...\n")
            output:write("I herd tales of these islands being huanted.\n")
            output:write("Gosh darn it all! I forgot to bring my favorite news paper.\n")
            output:write("I think this place sucks...\n")
           output:write("Back in the day I use to be more active....That is when I when I watched tv and needed to grab a snack...\n")
           output:write("I could have sworn I herd a noise,I sure hope it's just my imagination...\n")
           output:write("I could remember the time I went fishing when I was a wee lad,ah those were the good old days...\n")
           output:write("Just my luck,my new watch is broken...\n")
           output:write("If only I had just staied in bed and not tried showing off...\n")
output:write("*sniff,sniff* Something smells musky...\n")
output:write("*sings* No body's gonna break my stride oh no I got to keep on moving...\n")
output:write("*sings* Lonely,I'm Mr.lonely, I have nobody for my own ooooohh....\n")
output:write("I'm gonna go insane here,I can't do without my Pepsi!\n")
output:write("*grumble* I would love to eat a peanutbutter and jelly sandwhich right about now...\n")
output:write("List of things I don't have, no icecream, no pepsi, no tv, no warm bed, and soon no hope...\n")
output:write("Ow! a darn mosquito bit me! Darn pesky bug. Shoot, I didn't even pack any OFF spray with me...\n")
output:write("I'm missing my favorite tv shows...\n")
output:write("Aw man,I didn't even bring any cards with me,I can't even play Solitaire alone...\n")
output:write("At least after all this traveling,I'll be a famous old geezer ha,ha,ha! *cough,cough*\n")
output:write("*mumbles nonsense*\n")
output:write("I remember the time my wife would call me in the house for supper, Wilber,come and get it!\n")
output:write("I remember the time when I use to could remember....\n")
output:write("I miss my grand kids,at least I had somebody to talk to...\n")
output:write("I miss my grand kids,at least they brung me candy....\n")
output:write("I think I lost my dentures...wait no here they are...\n")
output:write("I sure wish I had a hot cup of coffee....\n")
output:write("Some chicken noodle soup would go good right about now...with some crackers...\n")
output:write("Why,back in the day I use to be in the marathon! From the sofa to the fridge and back!\n")
output:write("*sings* Gotta catch em all Pokemon,doo,doo,doo,doo. *hums* hmmm,hmm,hm,hmmmm.\n")
output:write("I remember the time my grand kids asked me, Hey old pops,what's the difference between Pokemon and Digimon...and I told them,the heck if I know...\n")
output:write("I remember the time I watched Digimon and I was looking for Pikachu the whole time....\n")
output:write("Back in my days I use to play Pacman....\n")
output:write("Back in my days I use to play Pitfall....\n")
output:write("Back in my days I use to play Duckhunt...now I'm hungry,I want some fried duck...\n")
output:write("Ow,my legs are all itchy,and I can't scratch them because I wasn't animated to be able to....thanks alot...\n")
output:write("The Black Wolf is evil I tell ya! He took my last bag of cookies before I got dropped off on this Island! That fiend!\n")
output:write("I wish ThunderWufe was here,he's take care of the monsters for me and I could just sleep....\n")
output:write("I left my cellphone on the table back at home....nooooo! No more Facebook!\n")
output:write("When I return home some day I'm gonna dive into bed and never come back out....\n")
output:write("I out lived all my thirty seven siblings...\n")
output:write("Is there any wind around here?\n")
output:write("I gotta remember to never ever take any more bets...\n")
output:write("*cough,cough* Hmm,it seems time around here sure is quick...\n")
output:write("*cough,cough,cough* Huuu...*cough,cough,cough* Yuck....\n")
output:write("*sneezes* Uhhh....my nose....\n")
output:write("*yawns* ooooooh.....getting drowsy here....\n")
output:write("Wish I could play chess with somebody....\n")
output:write("I miss my cat Whiskers and my old dog Messupeverything...that's all he ever did was mess up everything...ha,ha...\n")
output:write("*sigh* Sure is lonely around this place...\n")
output:write("I even miss my neighbors right now...I have nobody to complain to...\n")
output:write("I could have sworn I seen floating Islands...am I dreaming all of this???\n")
output:write("Thank goodness I watched survival man back in the day before I got stuck into this situation...\n")
output:write("I bet if I had enough logs I could make a raft so I could rest my feet and not have to swim...\n")
output:write("I'm glad I didn't take the bet to live on shark islands....\n")
output:write("At least there's no zombies...this is the wilderness for crying out loud not the apocalypse!\n")
output:write("Kinda wish the Oogoos were nice people...But nope,hateful grumpy cavemen....\n")
output:write("I didn't even pack a compass with me?! Oh man....\n")
output:write("I'm hungry for a hershe bar,or maybe a zero candy....\n")
output:write("Sure wish I packed some Pringles and my Pepsi....\n")
		io.close(output)
		input = io.open(minetest.get_worldpath().."/random_messages","r")
	end
	for line in input:lines() do
		random_messages.messages[line_number] = line
		line_number = line_number + 1
	end
	io.close(input)
end

function random_messages.display_message(message_number)
	local msg = random_messages.messages[message_number] or message_number
	if msg then
		minetest.chat_send_all(msg)
	end
end

function random_messages.show_message()
	random_messages.display_message(table.random(random_messages.messages))
end

function random_messages.list_messages()
	local str = ""
	for k,v in pairs(random_messages.messages) do
		str = str .. k .. " | " .. v .. "\n"
	end
	return str
end

function random_messages.remove_message(k)
	table.remove(random_messages.messages,k)
	random_messages.save_messages()
end

function random_messages.add_message(t)
	table.insert(random_messages.messages,table.concat(t," ",2))
	random_messages.save_messages()
end

function random_messages.save_messages()
		local output = io.open(minetest.get_worldpath().."/random_messages","w")
		for k,v in pairs(random_messages.messages) do
			output:write(v .. "\n")
		end
		io.close(output)
end

--When server starts:
random_messages.set_interval()
random_messages.read_messages()

local TIMER = 0
minetest.register_globalstep(function(dtime)
	TIMER = TIMER + dtime;
	if TIMER > MESSAGE_INTERVAL then
		random_messages.show_message()
		TIMER = 0
	end
end)

local register_chatcommand_table = {
	params = "viewmessages | removemessage <number> | addmessage <number>",
	privs = {server = true},
	description = "View and/or alter the server's random messages",
	func = function(name,param)
		local t = string.split(param, " ")
		if t[1] == "viewmessages" then
			minetest.chat_send_player(name,random_messages.list_messages())
		elseif t[1] == "removemessage" then
			if not random_messages.check_params(
			name,
			function (params)
				if not tonumber(params[2]) or
				random_messages.messages[tonumber(params[2])] == nil then
					return false,"ERROR: No such message."
				end
				return true
			end,
			t) then return end
			random_messages.remove_message(t[2])
		elseif t[1] == "addmessage" then
			if not t[2] then
				minetest.chat_send_player(name,"ERROR: No message.")
			else
				random_messages.add_message(t)
			end
		else
				minetest.chat_send_player(name,"ERROR: Invalid command.")
		end
	end
}

minetest.register_chatcommand("random_messages", register_chatcommand_table)
minetest.register_chatcommand("rmessages", register_chatcommand_table)
