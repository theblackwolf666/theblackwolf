-- if true, you have to punch the sieve to operate
-- if false, the sieve will operate automatically
gravelsieve.manually = false
