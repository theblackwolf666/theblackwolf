# Gravel Sieve Mod
A Mod for those who do not want to spend half their lives underground...

Inspired from a Minecr**t Video on YT.

This mod simplifies the extraction of ores by the fact that ores can be obtained simply by sieving gravel.

This mod includes two new tools:
 - a hammer to produce gravel from Cobblestone
 - a gravel sieve to find ores

Browse on: ![GitHub](https://github.com/joe7575/Minetest-Gravelsieve)

Download: ![GitHub](https://github.com/joe7575/Minetest-Gravelsieve/archive/master.zip)


## Dependencies
default  

# License
Copyright (C) 2017 Joachim Stolberg  
Code: Licensed under the GNU LGPL version 2.1 or later. See LICENSE.txt and http://www.gnu.org/licenses/lgpl-2.1.txt  
Textures: CC0

