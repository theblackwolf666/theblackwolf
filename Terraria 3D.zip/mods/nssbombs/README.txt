NSSbombs

This mod for minetest, extracted from nssm (https://github.com/NPXcoot/nssm),
aims to be a really simple way for everyone to define objects that you can
throw (and to obtain what you want when they touch the ground).
