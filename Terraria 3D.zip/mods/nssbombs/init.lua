--Not So Simple Bombs
nssbombs = {}
local path = minetest.get_modpath("nssbombs")

dofile(path.."/bombs_api.lua")
dofile(path.."/bombs_examples.lua")
