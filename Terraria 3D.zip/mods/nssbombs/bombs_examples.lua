--Tnt Bomb
nssbombs:register_throwitem("nssbombs:tnt_bomb", "TNT explosion bomb", {
    textures = "bomb_bomb.png",
    recipe_block = "tnt:tnt",
    recipe_number = 6,
    explosion = {
        shape = "tnt_explosion",
        radius = 5,
    }
})