--Meteor Spawner--

minetest.register_abm({
	nodenames = {"meteor:meteor_summoner"},
	interval = 60,
	chance = 1,
	action = function(pos)
		minetest.add_node(pos, {name="meteor:meteor"})
	end,
})

--Reg.SPAWN--


minetest.register_ore({
	ore_type       = "scatter",
	ore            = "meteor:meteor",
	wherein        = "default:dirt",
	clust_scarcity = 80*20*80,
	clust_num_ores = 15,
	clust_size     = 3,
	height_min     = -20,
	height_max     = 250,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "meteor:meteor",
	wherein        = "default:dirt_with_grass",
	clust_scarcity = 80*20*80,
	clust_num_ores = 15,
	clust_size     = 3,
	height_min     = 0,
	height_max     = 31000,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "meteor:meteor",
	wherein        = "default:desert_sand",
	clust_scarcity = 80*20*80,
	clust_num_ores = 15,
	clust_size     = 3,
	height_min     = 0,
	height_max     = 31000,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "meteor:meteor",
	wherein        = "default:sand",
	clust_scarcity = 80*20*80,
	clust_num_ores = 15,
	clust_size     = 3,
	height_min     = 0,
	height_max     = -100,
	flags          = "absheight",
})