
minetest.register_craft({
	output = 'meteor:meteor_pick',
	recipe = {
		{'', 'meteor:meteor_bar', 'meteor:meteor_bar'},
		{'', 'group:stick', 'meteor:meteor_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'meteor:meteor_axe',
	recipe = {
		{'meteor:meteor_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'meteor:meteor_sword',
	recipe = {
		{'', '', 'meteor:meteor_bar'},
		{'', 'meteor:meteor_bar', ''},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	type = "fuel",
	recipe = "meteor:meteor_chunk",
	burntime = 390,
})

minetest.register_craft({
	type = "cooking",
	output = "meteor:meteor_bar",
	recipe = "meteor:meteor_chunk",
})