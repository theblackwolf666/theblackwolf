
minetest.register_node("meteor:meteor", {
      description = "Meteor",
	tiles = {"meteor_meteor.png"},
	is_ground_content = true,
	groups = {cracky=3, hot=3, falling_node=1, stone=1},
	light_source = 23,
      drop = 'meteor:meteor_chunk',
})

minetest.register_node("meteor:meteor_summoner", {
	description = "Meteor Summoner",
	tiles = {"meteor_meteor_summoner_top.png", "meteor_meteor_summoner_top.png", "meteor_meteor_summoner_side.png"},
	is_ground_content = true,
	groups = {not_in_creative_inventory = 1,cracky=2},
})