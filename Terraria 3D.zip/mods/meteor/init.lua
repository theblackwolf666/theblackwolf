
dofile(minetest.get_modpath("meteor").."/meteor_spawn.lua")
dofile(minetest.get_modpath("meteor").."/meteor_items.lua")
dofile(minetest.get_modpath("meteor").."/meteor_nodes.lua")
dofile(minetest.get_modpath("meteor").."/meteor_tools.lua")
dofile(minetest.get_modpath("meteor").."/craft_recipes.lua")
