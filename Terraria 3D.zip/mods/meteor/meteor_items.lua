
minetest.register_craftitem("meteor:meteor_chunk", {
	description = "Meteor Chunk",
stack_max = 999,
	inventory_image = "meteor_meteor_chunk.png",
})

minetest.register_craftitem("meteor:meteor_bar", {
	description = "Meteor Bar",
stack_max = 999,
	inventory_image = "meteor_meteor_bar.png",
})