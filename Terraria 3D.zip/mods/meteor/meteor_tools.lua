minetest.register_tool("meteor:meteor_pick", {
	description = "Meteor Pickaxe",
	inventory_image = "meteor_tool_meteorpick.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			cracky = {times={[1]=4.00, [2]=1.60, [3]=0.80}, uses=450, maxlevel=1},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("meteor:meteor_axe", {
	description = "Meteor Axe",
	inventory_image = "meteor_tool_meteoraxe.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.50, [2]=1.40, [3]=1.00}, uses=450, maxlevel=1},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("meteor:meteor_sword", {
	description = "Meteor Sword",
	inventory_image = "meteor_tool_meteorsword.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=2.5, [2]=1.20, [3]=0.35}, uses=300, maxlevel=1},
		},
		damage_groups = {fleshy=7},
	}
})