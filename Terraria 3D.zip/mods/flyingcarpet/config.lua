flyingcarpet = {}

--If you want carpets to be available only through /giveme or at admin shops, set this to false.
flyingcarpet.crafts = true

--If you want flying carpets to be only one use, set this to true.
flyingcarpet.one_use = false
