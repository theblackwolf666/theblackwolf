[mod] 3d Armor Stand [3d_armor_stand]
=====================================

Depends: 3d_armor

Adds a chest-like armor stand for armor storage and display.

Crafting
--------

F = Wooden Fence [default:fence_wood]
S = Steel Ingot [default:steel_ingot]

+---+---+---+
|   | F |   |
+---+---+---+
|   | F |   |
+---+---+---+
| S | S | S |
+---+---+---+

