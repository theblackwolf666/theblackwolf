-- get intllib optionally
if (minetest.get_modpath("intllib")) then
	dofile(minetest.get_modpath("intllib").."/intllib.lua")
	S = intllib.Getter(minetest.get_current_modname())
else
	S = function ( s ) return s end
end

--Register beanstalk nodes
minetest.register_node("magicbeans_w:leaves", {
	description = S("magic beanstalk leaves"),
	tiles = {"magicbeans_w_leaves.png"},
	inventory_image = "magicbeans_w_leaves.png",
	drawtype = "plantlike",
	walkable = false,
	climbable = true,
	paramtype = "light",
	groups = {leaves = 1, snappy = 3, flammable = 2},
	sounds = default.node_sound_leaves_defaults()
})

minetest.register_node("magicbeans_w:blank", {
	description = S("magic beanstalk climbable blank"),
	drawtype = "airlike",
	inventory_image = "unknown_node.png",
	wield_image = "unknown_node.png",
	walkable = false,
	climbable = true,
	paramtype = "light",
	buildable_to = true,
	pointable = false,
	diggable = false,
	drop = "",
	groups = {not_in_creative_inventory = 1},
})

minetest.register_node("magicbeans_w:stem", {
	description = S("magic beanstalk stem"),
	tiles = {"magicbeans_w_stem_topbottom.png", "magicbeans_w_stem_topbottom.png", "magicbeans_w_stem.png"},
	paramtype2 = "facedir",
	groups = {oddly_breakable_by_hand = 1, choppy = 3, flammable = 2},
	sounds = default.node_sound_wood_defaults(),
	on_place = minetest.rotate_node,
})

minetest.register_node("magicbeans_w:cloud", {
	description = S("cloud"),
	tiles = {"default_cloud.png"},
	walkable = false,
	climbable = true,
	paramtype = "light",
	sunlight_propagates = true,
	groups = {dig_immediate = 3},
	sounds =	{ dig = { name = "", gain = 0 }, footstep = { name = "", gain = 0 },
			  dug = { name = "", gain = 0 }, player = { name = "", gain = 0 } }
})

magicbeans_w_list = {
   { S("magic beanstalk bean"), nil, "beanstalk", nil, nil, nil, nil},
}

for i in ipairs(magicbeans_w_list) do
	
    local beandesc = magicbeans_w_list[i][1]
    local effdesc = magicbeans_w_list[i][2]
    local bean = magicbeans_w_list[i][3]
    local beangroups = magicbeans_w_list[i][7]
	
		--Register beans
	minetest.register_craftitem("magicbeans_w:"..bean, {
		description = beandesc,
		inventory_image = "magicbeans_w_"..bean..".png",
		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.above then
				if bean ~= "beanstalk" then
					minetest.env:add_item(pointed_thing.above, {name="magicbeans_w:"..bean})
				else
					-- Grow Beanstalk
					minetest.chat_send_player(placer:get_player_name(),S("It's gonna grow - wait for it!"))
					math.randomseed(os.time())
					local stalk = pointed_thing.above
					stalk.x = stalk.x - 2
					stalk.z = stalk.z - 2
					local height = 127 - stalk.y
					local c = {1, 1, 1, 1, 2, 1, 1, 1, 1}
					local d = {1, 2, 3, 6}
					local e = {9, 8, 7, 4}
					local ex = 0
					local zed = 1
					local blank = 0
					for why = 0,height do
						blank = blank + 1
						if blank > 4 then blank = 1 end
						why1 = stalk.y + why
						for i = 1,9 do
							ex = ex + 1
							if ex > 3 then
								zed = zed + 1
								ex = 1
							end
							if c[i] == 1 then
								node = "magicbeans_w:leaves"
								if i == d[blank] or i == e[blank] then node = "magicbeans_w:blank" end
							else
								node = "magicbeans_w:stem"
							end
							ex1 = stalk.x + ex
							zed1 = stalk.z + zed
							minetest.set_node({x=ex1, y=why1, z=zed1},{name=node})
						end
						zed = 0
					end
					-- Build cloud platform
					for ex = -10,20 do
						for zed = -10,20 do
							ex1 = stalk.x + ex
							zed1 = stalk.z + zed
							minetest.set_node({x=ex1, y=why1, z=zed1},{name="magicbeans_w:cloud"})
						end	
					end				
				end
				itemstack:take_item()
			end
			return itemstack
		end,
		on_use = function(itemstack, user, pointed_thing)
			if bean == "beanstalk" then
				minetest.chat_send_player(user:get_player_name(),S("You can't eat magic beanstalk beans - you have to plant them."))	
				return
			end
			playereffects.apply_effect_type("bean_"..bean, 30, user)
			itemstack:take_item()
			return itemstack
		end, 
	})	
	
end

-- Remove beanstalk blanks
minetest.register_abm(
	{nodenames = {"magicbeans_w:blank"},
	interval = 5,
	chance = 1,
	action = function(pos)
		local neighbors = {
			{ x=pos.x, y=pos.y, z=pos.z-1 },
			{ x=pos.x, y=pos.y, z=pos.z+1 },
			{ x=pos.x, y=pos.y-1, z=pos.z },
			{ x=pos.x, y=pos.y+1, z=pos.z },
			{ x=pos.x-1, y=pos.y, z=pos.z },
			{ x=pos.x+1, y=pos.y, z=pos.z },
		}
		local attached = false
		for i=1,#neighbors do
			local node = minetest.get_node_or_nil(neighbors[i])
			if(node ~= nil) then
				if node.name == "magicbeans_w:leaves" or node.name == "magicbeans_w:stem" then
					attached = true
					break
				end
			end
		end
		if(attached == false) then
			minetest.remove_node(pos)
		end
	end
})
