﻿threates / evil npc for aliveai

worker:
right click the bot then you can choose:


dig:
list nodes names and groups to dig, like:
"default:dirt,default:tree,group:stone..."

take:
position (x,y,z) of the chest/node the bots can take items from.
and the name of the inventory, leave the option to make it add "main" by is self:
"x,y,z,main" or "x,y,z"
e.g:
"234,392,-432,storge"

add:
same as above, but will add items instead
"x,y,z,main" or "x,y,z"
e.g:
"234,392,-432,storge"

place:
place nodes on a position
"x,y,z,node"
e.g:
"234,392,-432,default:wood"