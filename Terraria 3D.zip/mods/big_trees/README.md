# big_trees

This mod spawns huge trees, hundreds of meters high, every so often. Inside are hollow areas ideal for any mobs you might want to introduce.


The source is available on github.

Code: LGPL2
Textures: CC0, GFDL

Mod dependencies: default

Download: https://github.com/duane-r/big_trees/archive/master.zip
