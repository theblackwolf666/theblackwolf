
## flowerpot API

`flowerpot.register_node(name)`
  * name = node name, e.g. "default:sapling"
  * the node must be defined and registered first using `minetest.register_node()`.
