#myitemchest

A Minetest mod that is a chest. When you open it items pop out. After that you can use the chest as a regular chest.

Licence - DWYWPL
