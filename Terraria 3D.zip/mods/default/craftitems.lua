-- mods/default/craftitems.lua

minetest.register_craftitem("default:stick", {
	description = "Oak Stick",
stack_max = 999,
	inventory_image = "default_stick.png",
	groups = {stick = 1},
})

minetest.register_craftitem("default:aspenstick", {
	description = "Aspen Limb",
stack_max = 999,
	inventory_image = "default_stick_aspen.png",
	groups = {stick = 1},
})

minetest.register_craftitem("default:junglestick", {
	description = "Jungle Stick",
stack_max = 999,
	inventory_image = "default_stick_jungle.png",
	groups = {stick = 1},
})

minetest.register_craftitem("default:pinestick", {
	description = "Pine Twig",
stack_max = 999,
	inventory_image = "default_stick_pine.png",
	groups = {stick = 1},
})

minetest.register_craftitem("default:mushstick", {
	description = "Mush Rod",
stack_max = 999,
	inventory_image = "default_stick_mush.png",
	groups = {stick = 1},
})

minetest.register_craftitem("default:paper", {
	description = "Paper",
stack_max = 999,
	inventory_image = "default_paper.png",
})

local lpp = 14 -- Lines per book's page
local function book_on_use(itemstack, user)
	local player_name = user:get_player_name()
	local data = minetest.deserialize(itemstack:get_metadata())
	local formspec, title, text, owner = "", "", "", player_name
	local page, page_max, lines, string = 1, 1, {}, ""

	if data then
		title = data.title
		text = data.text
		owner = data.owner

		for str in (text .. "\n"):gmatch("([^\n]*)[\n]") do
			lines[#lines+1] = str
		end

		if data.page then
			page = data.page
			page_max = data.page_max

			for i = ((lpp * page) - lpp) + 1, lpp * page do
				if not lines[i] then break end
				string = string .. lines[i] .. "\n"
			end
		end
	end

	if owner == player_name then
		formspec = "size[8,8]" .. default.gui_bg ..
			default.gui_bg_img ..
			"field[0.5,1;7.5,0;title;Title:;" ..
				minetest.formspec_escape(title) .. "]" ..
			"textarea[0.5,1.5;7.5,7;text;Contents:;" ..
				minetest.formspec_escape(text) .. "]" ..
			"button_exit[2.5,7.5;3,1;save;Save]"
	else
		formspec = "size[8,8]" .. default.gui_bg ..
			default.gui_bg_img ..
			"label[0.5,0.5;by " .. owner .. "]" ..
			"tablecolumns[color;text]" ..
			"tableoptions[background=#00000000;highlight=#00000000;border=false]" ..
			"table[0.4,0;7,0.5;title;#FFFF00," .. minetest.formspec_escape(title) .. "]" ..
			"textarea[0.5,1.5;7.5,7;;" ..
				minetest.formspec_escape(string ~= "" and string or text) .. ";]" ..
			"button[2.4,7.6;0.8,0.8;book_prev;<]" ..
			"label[3.2,7.7;Page " .. page .. " of " .. page_max .. "]" ..
			"button[4.9,7.6;0.8,0.8;book_next;>]"
	end

	minetest.show_formspec(player_name, "default:book", formspec)
end

minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= "default:book" then return end
	local inv = player:get_inventory()
	local stack = player:get_wielded_item()

	if fields.save and fields.title ~= "" and fields.text ~= "" then
		local new_stack, data
		if stack:get_name() ~= "default:book_written" then
			local count = stack:get_count()
			if count == 1 then
				stack:set_name("default:book_written")
			else
				stack:set_count(count - 1)
				new_stack = ItemStack("default:book_written")
			end
		else
			data = minetest.deserialize(stack:get_metadata())
		end

		if not data then data = {} end
		data.title = fields.title
		data.text = fields.text
		data.text_len = #data.text
		data.page = 1
		data.page_max = math.ceil((#data.text:gsub("[^\n]", "") + 1) / lpp)
		data.owner = player:get_player_name()
		local data_str = minetest.serialize(data)

		if new_stack then
			new_stack:set_metadata(data_str)
			if inv:room_for_item("main", new_stack) then
				inv:add_item("main", new_stack)
			else
				minetest.add_item(player:getpos(), new_stack)
			end
		else
			stack:set_metadata(data_str)
		end

	elseif fields.book_next or fields.book_prev then
		local data = minetest.deserialize(stack:get_metadata())
		if not data.page then return end

		if fields.book_next then
			data.page = data.page + 1
			if data.page > data.page_max then
				data.page = 1
			end
		else
			data.page = data.page - 1
			if data.page == 0 then
				data.page = data.page_max
			end
		end

		local data_str = minetest.serialize(data)
		stack:set_metadata(data_str)
		book_on_use(stack, player)
	end

	player:set_wielded_item(stack)
end)

minetest.register_craftitem("default:book", {
	description = "Book",
stack_max = 999,
	inventory_image = "default_book.png",
	groups = {book = 1},
	on_use = book_on_use,
})

minetest.register_craftitem("default:book_written", {
	description = "Book With Text",
	inventory_image = "default_book_written.png",
	groups = {book = 1, not_in_creative_inventory = 1},
	stack_max = 1,
	on_use = book_on_use,
})

minetest.register_craft({
	type = "shapeless",
	output = "default:book_written",
	recipe = {"default:book", "default:book_written"}
})

minetest.register_on_craft(function(itemstack, player, old_craft_grid, craft_inv)
	if itemstack:get_name() ~= "default:book_written" then
		return
	end

	local copy = ItemStack("default:book_written")
	local original
	local index
	for i = 1, player:get_inventory():get_size("craft") do
		if old_craft_grid[i]:get_name() == "default:book_written" then
			original = old_craft_grid[i]
			index = i
		end
	end
	if not original then
		return
	end
	local copymeta = original:get_metadata()
	-- copy of the book held by player's mouse cursor
	itemstack:set_metadata(copymeta)
	-- put the book with metadata back in the craft grid
	craft_inv:set_stack("craft", index, original)
end)

minetest.register_craftitem("default:coal_lump", {
	description = "Coal Lump",
stack_max = 999,
	inventory_image = "default_coal_lump.png",
	groups = {coal = 1}
})

minetest.register_craftitem("default:iron_lump", {
	description = "Iron Lump",
stack_max = 999,
	inventory_image = "default_iron_lump.png",
})

minetest.register_craftitem("default:copper_lump", {
	description = "Copper Lump",
stack_max = 999,
	inventory_image = "default_copper_lump.png",
})

minetest.register_craftitem("default:mese_crystal", {
	description = "Mese Crystal",
stack_max = 999,
	inventory_image = "default_mese_crystal.png",
})

minetest.register_craftitem("default:gold_lump", {
	description = "Gold Lump",
stack_max = 999,
	inventory_image = "default_gold_lump.png",
})

minetest.register_craftitem("default:diamond", {
	description = "Diamond",
stack_max = 999,
	inventory_image = "default_diamond.png",
})

minetest.register_craftitem("default:clay_lump", {
	description = "Clay Lump",
stack_max = 999,
	inventory_image = "default_clay_lump.png",
})

minetest.register_craftitem("default:steel_ingot", {
	description = "Steel Ingot",
stack_max = 999,
groups = {lead = 1},
	inventory_image = "default_steel_ingot.png",
})

minetest.register_craftitem("default:copper_ingot", {
	description = "Copper Ingot",
stack_max = 999,
	inventory_image = "default_copper_ingot.png",
})

minetest.register_craftitem("default:bronze_ingot", {
	description = "Bronze Ingot",
stack_max = 999,
	inventory_image = "default_bronze_ingot.png",
})

minetest.register_craftitem("default:gold_ingot", {
	description = "Gold Ingot",
stack_max = 999,
	inventory_image = "default_gold_ingot.png"
})

minetest.register_craftitem("default:mese_crystal_fragment", {
	description = "Mese Crystal Fragment",
stack_max = 999,
	inventory_image = "default_mese_crystal_fragment.png",
})

minetest.register_craftitem("default:clay_brick", {
	description = "Clay Brick",
stack_max = 999,
	inventory_image = "default_clay_brick.png",
})

minetest.register_craftitem("default:obsidian_shard", {
	description = "Obsidian Shard",
stack_max = 999,
	inventory_image = "default_obsidian_shard.png",
})

minetest.register_craftitem("default:flint", {
	description = "Flint",
stack_max = 999,
	inventory_image = "default_flint.png"
})

minetest.register_craftitem("default:pumpkin_slice", {
	description = "Pumpkin Slice",
stack_max = 999,
	inventory_image = "default_pumpkin_slice.png",
      on_use = minetest.item_eat(3),
})

minetest.register_craftitem("default:cookedcati", {
	description = "Cooked Cacti",
stack_max = 999,
	inventory_image = "default_cc.png",
      on_use = minetest.item_eat(3),
})

minetest.register_craftitem("default:slime", {
	description = "Slime",
stack_max = 999,
	inventory_image = "default_slime.png",
})

local craftguide, datas, npp = {}, {}, 8*3

function craftguide:get_recipe(item)
	if item:sub(1,6) == "group:" then
		if item:sub(-4) == "wool" or item:sub(-3) == "dye" then
			item = item:sub(7)..":white"
		elseif core.registered_items["default:"..item:sub(7)] then
			item = item:gsub("group:", "default:")
		else for node, def in pairs(core.registered_items) do
			 if def.groups[item:match("[^,:]+$")] then item = node end
		     end
		end
	end
	return item
end

function craftguide:get_formspec(player_name, pagenum, recipe_num)
	local data = datas[player_name]
	local formspec = [[ size[8,7.6;]
			image[0,0;1,1;default_craft_guide.png]
			label[1,0.25;Crafting Guide]
			tablecolumns[color;text;color;text]
			tableoptions[background=#00000000;highlight=#00000000;border=false]
			button[5.4,1;0.8,0.95;prev;<]
			button[7.2,1;0.8,0.95;next;>]
			button[2.5,1.2;0.8,0.5;search;?]
			button[3.2,1.2;0.8,0.5;clear;X]
			tooltip[search;Search]
			tooltip[clear;Reset]
			table[6,1.18;1.1,0.5;pagenum;#FFFF00,]]..
			pagenum..",#FFFFFF,/ "..data.pagemax.."]"..
			"field[0.3,1.32;2.6,1;filter;;"..data.filter.."]"..
			default.gui_bg..default.gui_bg_img

	local i, s = 0, 0
	for _, name in pairs(data.items) do
		if s < (pagenum - 1) * npp then
			s = s + 1
		else if i >= npp then break end
			local X = i % 8
			local Y = ((i-X) / 8) + 2

			formspec = formspec.."item_image_button["..X..","..Y..";1,1;"..
					     name..";"..name..";]"
			i = i + 1
		end
	end

	if data.item and core.registered_items[data.item] then
		local recipes = core.get_all_craft_recipes(data.item)
		if recipe_num > #recipes then recipe_num = 1 end

		if #recipes > 1 then formspec = formspec..
			[[ button[0,7;2.6,1;alternate;Alternate]
			label[0,6.5;Recipe ]]..recipe_num.." of "..#recipes.."]"
		end

		local type = recipes[recipe_num].type
		if type == "cooking" then formspec = formspec..
			"image[3.475,5.1;1,1;" .. core.inventorycube("default_furnace_top.png", "default_furnace_front.png", "default_furnace_side.png") .. "]"
		end

		local items = recipes[recipe_num].items
		local width = recipes[recipe_num].width
		if width == 0 then width = math.min(3, #items) end
		-- Lua 5.3 removed `table.maxn`, use this alternative in case of breakage:
		-- https://github.com/kilbith/xdecor/blob/master/handlers/helpers.lua#L1
		local rows = math.ceil(table.maxn(items) / width)

		for i, v in pairs(items) do
			local X = (i-1) % width + 4.5
			local Y = math.floor((i-1) / width + (6 - math.min(2, rows))) + 1
			local label = ""
			if v:sub(1,6) == "group:" then label = "\nG" end

			formspec = formspec.."item_image_button["..X..","..Y..";1,1;"..
					     self:get_recipe(v)..";"..self:get_recipe(v)..";"..label.."]"
		end

		local output = recipes[recipe_num].output
		formspec = formspec..[[ image[3.5,6;1,1;gui_furnace_arrow_bg.png^[transformR90]
				        item_image_button[2.5,6;1,1;]]..output..";"..data.item..";]"
	end

	data.formspec = formspec
	core.show_formspec(player_name, "craft_guide", formspec)
end

function craftguide:get_items(player_name)
	local items_list, data = {}, datas[player_name]
	for name, def in pairs(core.registered_items) do
		if not (def.groups.not_in_creative_inventory == 1) and
				core.get_craft_recipe(name).items and
				def.description and def.description ~= "" and
				(def.name:find(data.filter, 1, true) or
					def.description:lower():find(data.filter, 1, true)) then
			items_list[#items_list+1] = name
		end
	end

	table.sort(items_list)
	data.items = items_list
	data.size = #items_list
	data.pagemax = math.ceil(data.size / npp)
end

core.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= "craft_guide" then return end
	local player_name = player:get_player_name()
	local data = datas[player_name]
	local formspec = data.formspec
	local pagenum = tonumber(formspec:match("#FFFF00,(%d+)")) or 1

	if fields.clear then
		data.filter, data.item = "", nil
		craftguide:get_items(player_name)
		craftguide:get_formspec(player_name, 1, 1)
	elseif fields.alternate then
		local recipe_num = tonumber(formspec:match("Recipe%s(%d+)")) or 1
		recipe_num = recipe_num + 1
		craftguide:get_formspec(player_name, pagenum, recipe_num)
	elseif fields.search then
		data.filter = fields.filter:lower()
		craftguide:get_items(player_name)
		craftguide:get_formspec(player_name, 1, 1)
	elseif fields.prev or fields.next then
		if fields.prev then pagenum = pagenum - 1
		else pagenum = pagenum + 1 end
		if     pagenum > data.pagemax then pagenum = 1
		elseif pagenum == 0	      then pagenum = data.pagemax end
		craftguide:get_formspec(player_name, pagenum, 1)
	else for item in pairs(fields) do
		 if core.get_craft_recipe(item).items then
			data.item = item
			craftguide:get_formspec(player_name, pagenum, 1)
		 end
	     end
	end
end)

core.register_craftitem("default:craft_guide", {
	description = "Crafting Guide",
	inventory_image = "default_craft_guide.png",
	wield_image = "default_craft_guide.png",
	stack_max = 1,
	groups = {book = 1},
	on_use = function(itemstack, user)
		local player_name = user:get_player_name()
		if not datas[player_name] then
			datas[player_name] = {}
			datas[player_name].filter = ""
			craftguide:get_items(player_name)
			craftguide:get_formspec(player_name, 1, 1)
		else
			core.show_formspec(player_name, "craft_guide", datas[player_name].formspec)
		end
	end
})

-- Crafting

core.register_craft({
	output = "default:craft_guide",
	type = "shapeless",
	recipe = {"default:book"}
})

minetest.register_craftitem("default:lead_ingot", {
	description = "Lead Ingot",
stack_max = 999,
groups = {lead = 1},
	inventory_image = "default_lead_ingot.png",
})

minetest.register_craftitem("default:lead_lump", {
	description = "Lead Lump",
stack_max = 999,
	inventory_image = "default_lead_lump.png",
})