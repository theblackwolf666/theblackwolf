[mod] Hazmat Suit [hazmat_suit]
===============================

Adds hazmat suit to 3d_armor. It protects rather well from fire (if enabled in configuration) and radiation*, and it has built-in oxygen supply.

Requires technic mod.

*Requires patched version of technic mod - https://github.com/minetest-technic/technic/pull/275

Depends: 3d_armor, technic

Textures by HybridDog and numberZero
