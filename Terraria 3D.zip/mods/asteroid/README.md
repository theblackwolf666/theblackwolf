Asteroid Crystals
==========

D.Kartaschew, I.Kartaschew and G.Kartaschew

Designed by I.Kartaschew and G.Kartaschew

Implemented by D.Kartaschew

For Minetest 0.4.15 and later

### Depends: 

* default
* fire

## Licenses: 

Code MIT. 
Media (textures) CC BY-SA 3.0
Some textures are derived from assets from Minetest, and are released under LGPLv2.1+

See license.txt for license information

## Description

An asteroid has crashed and spread crystals amongst the land. Be quick before they take over!

## Installation

Download the *.zip file, extract into your mods folder, and rename the folder to "asteroid_crystals".

Crafting
--------

Nil...
