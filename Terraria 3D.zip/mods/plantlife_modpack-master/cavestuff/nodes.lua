--Rocks

local cbox = {
	type = "fixed",
	fixed = {-5/16, -8/16, -6/16, 5/16, -1/32, 5/16},
}

minetest.register_node("cavestuff:pebble_1",{
      description = "Rock",
	drawtype = "mesh",
stack_max = 999,
	mesh = "cavestuff_pebble.obj",
    tiles = {"undergrowth_pebble.png"},
    inventory_image = "undergrowth_rock.png",
    paramtype = "light",
	paramtype2 = "facedir",
    groups = {cracky=3, dig_immediate=3, stone=1},
    selection_box = cbox,
    collision_box = cbox,
    on_place = function(itemstack, placer, pointed_thing)
		-- place a random pebble node
		local stack = ItemStack("cavestuff:pebble_"..math.random(1,2))
		local ret = minetest.item_place(stack, placer, pointed_thing)
		return ItemStack("cavestuff:pebble_1 "..itemstack:get_count()-(1-ret:get_count()))
	end,
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("cavestuff:pebble_2",{
	drawtype = "mesh",
	mesh = "cavestuff_pebble.obj",
    tiles = {"undergrowth_pebble.png"},
	drop = "cavestuff:pebble_1",
    tiles = {"undergrowth_pebble.png"},
    paramtype = "light",
	paramtype2 = "facedir",
    groups = {cracky=3, dig_immediate=3, stone=1, not_in_creative_inventory=1},
	selection_box = cbox,
	collision_box = cbox,
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("cavestuff:desert_pebble_1",{
      description = "Desert Rock",
	drawtype = "mesh",
stack_max = 999,
	mesh = "cavestuff_pebble.obj",
    tiles = {"default_sand.png"},
    inventory_image = "undergrowth_rocky.png",
    paramtype = "light",
	paramtype2 = "facedir",
    groups = {cracky=3, dig_immediate=3, stone=1},
	selection_box = cbox,
	collision_box = cbox,
    on_place = function(itemstack, placer, pointed_thing)
		-- place a random pebble node
		local stack = ItemStack("cavestuff:desert_pebble_"..math.random(1,2))
		local ret = minetest.item_place(stack, placer, pointed_thing)
		return ItemStack("cavestuff:desert_pebble_1 "..itemstack:get_count()-(1-ret:get_count()))
	end,
    sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("cavestuff:desert_pebble_2",{
	drawtype = "mesh",
	mesh = "cavestuff_pebble.obj",
	drop = "cavestuff:desert_pebble_1",
    tiles = {"default_sand.png"},
    paramtype = "light",
	paramtype2 = "facedir",
    groups = {cracky=3, dig_immediate=3, stone=1, not_in_creative__inventory=1},
	selection_box = cbox,
	collision_box = cbox,
    sounds = default.node_sound_stone_defaults(),
})