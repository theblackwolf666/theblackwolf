dofile(minetest.get_modpath('arctic_life')..'/penguin.lua')
dofile(minetest.get_modpath('arctic_life')..'/walrus.lua')
